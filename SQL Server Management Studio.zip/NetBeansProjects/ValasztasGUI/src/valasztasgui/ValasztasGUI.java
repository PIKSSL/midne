
package valasztasgui;

import javax.swing.JOptionPane;

public class ValasztasGUI {

    public static void main(String[] args) {
        Object ob = "Ezt tudjuk, hogy lehet null. Csináld meg a másikat...";
        String sz = "Most legyen a fejlécbe szöveg.";
        JOptionPane.showMessageDialog(null, ob,sz ,JOptionPane.INFORMATION_MESSAGE);
        int result = JOptionPane.showConfirmDialog(null, ob, sz, JOptionPane.YES_NO_OPTION);
        System.out.println(result);
        Object[] options = {"Op1","Op2","Op3"};
        Object something = JOptionPane.showInputDialog(null, ob, sz, JOptionPane.QUESTION_MESSAGE, null, options, null);
        System.out.println(something);
        int choice = JOptionPane.showOptionDialog(null, ob, sz, 0, 0, null, options, null);
    }
    
}
