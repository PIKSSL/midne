
package kiralynok;

import java.util.Random;

public class Tabla {
    private final Random rnd = new Random();
    private char[][] T;
    private char UresCella;
    
    
    public Tabla(char karakter) {
        T = new char[8][8];
        UresCella=karakter;
        feltolt();
        
    }   
    
    public void feltolt(){
        for (int i = 0; i < T[0].length; i++) {
            for (int j = 0; j < T[i].length; j++) {
                T[i][j]=UresCella;
            }
        }
    }
    
    public void elhelyez(char karakter){
        int index1,index2;
        int index = rnd.nextInt(7);
        do {            
            index1 = rnd.nextInt(7);
            index2 = rnd.nextInt(7);
        } while (T[index1][index2]==karakter);
        
        
    }
    public void fajlbair(){
        
    }
    public void megjelenit(){
        StringBuilder st = new StringBuilder();
        String tabla = "";
        for (int i = 0; i < T[0].length; i++) {
            for (int j =0; j < T[i].length; j++) {
                st.append(T[i][j]);
            }
            tabla+=st+ "\n";
            st.delete(0, st.length());
        }
        System.out.println(tabla);
 
    }
    public void tabla(){
        
    }
    public void uresOszlop(){
        
    }
    public void uresSor(){
        
    }
    
    
}
