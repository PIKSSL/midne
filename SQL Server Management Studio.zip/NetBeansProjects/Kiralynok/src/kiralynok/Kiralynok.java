
package kiralynok;

public class Kiralynok {

    public static void main(String[] args) {
        Tabla a = new Tabla('-');
        a.megjelenit();
        a.elhelyez('K');
        a.megjelenit();
    }
    
}
