
package controller;

import modell.SzamologepModell;
import view.SzamologepView;

public class Controller {
    
    public Controller(SzamologepModell modell, SzamologepView view){
        modell.addNumber(Double.parseDouble(view.input("1. szám:")));
        modell.addNumber(Double.parseDouble(view.input("2. szám:")));
        view.display(modell.getString()+"="+modell.getResult());
        modell.addNumber(Double.parseDouble(view.input("2. szám:")));
        view.display(modell.getString()+"="+modell.getResult());
    }
}
