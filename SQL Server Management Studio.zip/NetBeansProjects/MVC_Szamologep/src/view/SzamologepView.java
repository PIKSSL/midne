
package view;

import java.util.ArrayList;
import java.util.Scanner;

public class SzamologepView {
    Scanner scn = new Scanner(System.in);
   public SzamologepView(){
       
   }
   
   public String input(String title){
       System.out.println(title);
       String data = scn.nextLine();
       return data;
   }
   
   public void display(String data){
       System.out.println(data);
   }
}
