
package modell;

import java.util.ArrayList;

public class SzamologepModell {
    ArrayList<Double> numbers = new ArrayList<Double>();
    public SzamologepModell(){
        
    }
    
    public void addNumber(double num){
        numbers.add(num);
    }
    
    public double getResult(){
        double result=0;
        for (int i = 0; i < numbers.size(); i++) {
            
            if(numbers.get(i)<0){
               result-=numbers.get(i);
            }
            else{
                result+=numbers.get(i);
            }
            
        }
        return result;
    }
    public String getString(){
        String str = "";
        for (int i = 0; i < numbers.size(); i++) {

            if(numbers.get(i)<0){
                str+=numbers.get(i)+"-";
            }else{
                str+=numbers.get(i)+"+";
            }
           
        }
        return str.substring(0, str.length() - 1);
    }
    
    
}
