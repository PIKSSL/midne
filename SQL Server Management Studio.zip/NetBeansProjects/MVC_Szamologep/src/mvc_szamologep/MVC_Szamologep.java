
package mvc_szamologep;

import controller.Controller;
import modell.SzamologepModell;
import view.SzamologepView;

public class MVC_Szamologep {

    public static void main(String[] args) {
        new Controller(new SzamologepModell(), new SzamologepView());
    }
    
}
