
package idomok;

public class Gomb extends FaIdom{
    private double sugar;
    
    public Gomb(double sugar){
        this.sugar=sugar;
    }
    
    @Override
    public double terfogat() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
