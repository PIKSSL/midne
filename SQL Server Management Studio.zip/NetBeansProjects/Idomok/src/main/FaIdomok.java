
package main;

import idomok.FaIdom;
import java.util.ArrayList;
import java.util.List;

public class FaIdomok {
   private List<?> idomok;

    public FaIdomok() {
        this.idomok = new ArrayList<FaIdom>();
    }
   

   
   public double osszSuly(){
       return 0;
   }
   
   public double osszGombSuly(){
       return 0;
   }
   
   public FaIdom minV(){
       return null;
   }
   
   public FaIdom maxV(){
       return null;
   }
   
   public void run(){
   }
   
   
    
    
}
