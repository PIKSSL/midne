
package main;

public class Program {

    public static void main(String[] args) {
        new FaIdomok();
    } 
    
}
