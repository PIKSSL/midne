package main;

import java.util.ArrayList;
import java.util.List;
import modell.Henger;
import modell.LyukasHenger;

public class HengerProgram2 {

    private List<Henger> hengerek;

    public static void main(String[] args) {
        new HengerProgram2().run();

    }
    public HengerProgram2() {
        hengerek = new ArrayList<Henger>();
        //tesztesetek
//        hengerek.add(new LyukasHenger(0, 0, 0));
//        hengerek.add(new LyukasHenger(2, 2, 1.5));
//        hengerek.add(new LyukasHenger(1, 2, 3,0.2));
         hengerek.add(new Henger(0, 0));
//        hengerek.add(new Henger(0, 0));
//        hengerek.add(new Henger(0, 0));
    }
    
    private void run() {
        int db = Henger.getHengerDb();
        System.out.printf("Hengerek(%d db):\n", db);
        for (Henger henger : hengerek) {
            System.out.println(henger);
        }
        System.out.println("átlag térfogat: " + atlagTerfogat());
        System.out.println("csövek súlya: " + csovekSulya());
        System.out.printf("Összesen %d henger\n ", db);
    }

    public List<Henger> lista() {
        return hengerek;
    }

    public double atlagTerfogat() {
        double ossz = 0;
        for (Henger henger : lista()) {
           ossz+=henger.terfogat();
//            if(henger instanceof LyukasHenger){
//                ossz +=((LyukasHenger)henger).suly();
//            }
        }
        return ossz/Henger.getHengerDb();
    }

    public double csovekSulya() {
           double ossz = 0;
           for (Henger henger : lista()) {
            if(henger instanceof LyukasHenger cso){
                ossz+= cso.suly();
            }
        }
        return ossz;
    }
}
