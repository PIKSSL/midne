
package modell;

public class TomorHenger extends Henger {
    private double fajsuly;

    public TomorHenger(double sugar, double magassag,double fajsuly ) {
        super(sugar, magassag);
        setFajsuly(fajsuly);
    }

    public TomorHenger(double sugar, double magassag) {
        this(sugar, magassag,1);
    }

    public double getFajsuly() {
        return fajsuly;
    }

    public void setFajsuly(double fajsuly) {
        if (fajsuly<=0) {
            this.fajsuly = 0.5;
        }
    }

    @Override
    public String toString() {
        return super.toString()+"\n\t"+"TomorHenger{" + "fajsuly=" + fajsuly + '}';
    }
    
    public double suly(){
        return this.terfogat()*this.fajsuly;
    }
}
