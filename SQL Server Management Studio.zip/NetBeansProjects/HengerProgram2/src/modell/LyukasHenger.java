
package modell;

public class LyukasHenger extends TomorHenger {
    private double falvastagsag;

    public LyukasHenger(double sugar, double magassag,double fajsuly, double falvastagsag) {
        super(sugar, magassag,fajsuly);
        setFalvastagsag(falvastagsag);
    }

    public LyukasHenger(double sugar, double magassag, double falvastagsag ) {
        this(sugar, magassag,1,1);
    }

    public double getFalvastagsag() {
        return falvastagsag;
    }

    public void setFalvastagsag(double falvastagsag) {
         if (falvastagsag<=0) {
            this.falvastagsag = 0.5;
        }
    }

    @Override
    public String toString() {
        return super.toString()+"\n\t\t"+"LyukasHenger{" + "falvastagsag=" + falvastagsag + '}';
    }

    @Override
    public double terfogat() {
        Henger belso = new Henger (getSugar() - falvastagsag, getMagassag());
        Henger.setHengerDbCsokken();
        return belso.terfogat()-super.terfogat();
    }
    
    
}
