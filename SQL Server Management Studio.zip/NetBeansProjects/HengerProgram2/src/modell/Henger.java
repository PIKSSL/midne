
package modell;

public class Henger {
    public static int hengerDb=0;
    static{
        hengerDb=0;
    }
    private double sugar,magassag;

    public Henger(double sugar, double magassag) {
        setSugar(sugar);
        setMagassag(magassag);
        Henger.hengerDb++;
    }

    public static int getHengerDb() {
        return hengerDb;
    }

    public double getSugar() {
        return sugar;
    } 

    public double getMagassag() {
        return magassag;
    }

    public static void setHengerDbCsokken() {
        Henger.hengerDb--;
    }

    public void setSugar(double sugar) {
        if (sugar<=0) {
            this.sugar = 1;
        }
        
    }

    public void setMagassag(double magassag) {
        if (magassag<=0) {
            this.magassag = 1;
        }
    }

    @Override
    public String toString() {
        return "Henger{" + "sugar=" + sugar + ", magassag=" + magassag + '}';
    }
    
    public double terfogat(){
        return Math.pow(sugar, 2)*Math.PI*magassag;
    }
}
