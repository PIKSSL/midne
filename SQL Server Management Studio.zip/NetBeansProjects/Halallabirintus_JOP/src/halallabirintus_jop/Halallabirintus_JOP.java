
package halallabirintus_jop;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Halallabirintus_JOP {
    public final Object[] options = {"Start","Exit"};
    public final Object[] options2 = {"Kinyitom a dobozt","Észak felé"};
     public final Object[] options3 = {"Észak felé"};
    public static void main(String[] args) {
        new Halallabirintus_JOP().game();
    }
    
    public void game(){
        Icon img = new ImageIcon(this.getClass().getResource("/kepek/menu.png"));
        Icon o1 = new ImageIcon(this.getClass().getResource("/kepek/o1.png"));
        Icon o66 = new ImageIcon(this.getClass().getResource("/kepek/o66.png"));
        Icon o270_1 = new ImageIcon(this.getClass().getResource("/kepek/o270_1.png"));
        Icon o270_2 = new ImageIcon(this.getClass().getResource("/kepek/o270_2.png"));
        int choice = JOptionPane.showOptionDialog(null, "<html>Egy versenyre nevezel, aminek a lényege, hogy át kell kelni a halállabirintuson.<br> A labirintusban tárgyakat találhatsz és szörnyekkel kell harcoljál.</html>", "Halállabirintus",JOptionPane.OK_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE, null, options,null );
        System.out.println(choice);
        if(choice == JOptionPane.OK_OPTION){
            choice = JOptionPane.showOptionDialog(null, "<html>Miután öt percet haladtál lassan az alagútban, egy kőasztalhoz érsz, amely a bal oldali fal mellett áll.<br> Hat doboz van rajta, egyikükre a te neved festették.<br> Ha kiakarod nyitni a dobozt, lapozz a 270-re. <br>Ha inkább tovább haladsz észak felé, lapozz a 66-ra.</html>", "Halállabirintus",JOptionPane.OK_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE, o1, options2,null );
            if(choice == JOptionPane.OK_OPTION){
            choice = JOptionPane.showOptionDialog(null, "<html>A doboz teteje könnyedén nyílik. <br>Benne két aranypénzt találsz, és egy üzenetet, amely egy kis pergamenen neked szól. <br>Előbb zsebre vágod az aranyakat, aztán elolvasod az üzenetet: - „Jól tetted. <br>Legalább volt annyi eszed, hogy megállj és elfogadd az ajándékot. <br>Most azt tanácsolom neked, hogy keress és használj különféle tárgyakat, ha sikerrel akarsz áthaladni Halállabirintusomon.” Azaláírás Szukumvit. <br>Megjegyzed a tanácsot, apródarabokra téped a pergament, és tovább mészészak felé. <br>Lapozz a 66-ra.<html>", "Halállabirintus",JOptionPane.OK_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE, o1, options3,null );
            JOptionPane.showMessageDialog(null, null,"Halállabirintus",JOptionPane.INFORMATION_MESSAGE,o66);  
            }else{
                JOptionPane.showMessageDialog(null, null,"Halállabirintus",JOptionPane.INFORMATION_MESSAGE,o66);  
            }
        }else{
             
        }
        
    }
    
}
