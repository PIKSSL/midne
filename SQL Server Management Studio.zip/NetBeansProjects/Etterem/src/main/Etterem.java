
package main;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import modell.Asztal;
import modell.Etel;

public class Etterem {

    private ArrayList<Asztal> asztalok;
    private ArrayList<Etel> etelek;

    public Etterem() throws IOException {
        asztalok = new ArrayList<Asztal>();
        etelek = new ArrayList<Etel>();
        etlapFeltolt("etel.txt");
        rendelesFelvetel("etelek.txt");
        etlap();
    }
    
    public void kiszamlaz(){
        
    }
    
    public void etlap(){
        for (Etel etel : etelek) {
            System.out.println(etel.getEtelAr()+" "+etel.getEtelNeve());
        }
        for (Asztal asztal : asztalok) {
            System.out.println(asztal.getAzon());
            for (Etel etel : asztal.getTartalom()) {
                System.out.println(etel.getEtelNeve());
            }
        }
    }

    public void etlapFeltolt(String etelek) throws IOException{
        Path path = Paths.get(etelek);
        List<String> sorok = Files.readAllLines(path);
        String[] as;
        for (String sor : sorok) {
             as = sor.split("\\|");
             this.etelek.add(new Etel(as[0], Integer.parseInt(as[1])));
        }
    }
    
    public void rendelesFelvetel(String etlap) throws IOException{
        Path path = Paths.get(etlap);
        List<String> sorok = Files.readAllLines(path);
        Asztal aktualisAsztal = null;
        int index = 0;
        for (String sor : sorok) {
            if(Character.isUpperCase(sor.charAt(0))){
                aktualisAsztal = new Asztal(sor);
            }
            else if(sor.isEmpty()){
                asztalok.add(aktualisAsztal);
            }
            else {
                while(sor != etelek.get(index).getEtelNeve()){
                    index++;
                }
                aktualisAsztal.etelFelvesz(etelek.get(index));
                index=0;
            }
        }
    }
    
}
