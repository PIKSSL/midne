
package modell;

import java.util.ArrayList;

public class Asztal {
    private ArrayList<Etel> tartalom;
    private String azon;
    private int hely;

    public Asztal(String azon) {
        tartalom = new ArrayList<Etel>();
        this.azon = azon;
        hely = 4;
    }
    
    public int osszegez(){
        
        return 0;
    }

    public String getAzon() {
        return azon;
    }
    
    
    public ArrayList<Etel> getTartalom(){
        return tartalom;
    }
    
    public void etelFelvesz(Etel etel){
        tartalom.add(etel);
    }
    
    
}
