
package modell;

public class Etel {
    private String etelNeve;
    private int etelAr;

    public Etel(String etelNeve, int ar) {
        this.etelNeve = etelNeve;
        this.etelAr = ar;
    }

    public String getEtelNeve() {
        return etelNeve;
    }

    public int getEtelAr() {
        return etelAr;
    }
    
    
    
    
}
