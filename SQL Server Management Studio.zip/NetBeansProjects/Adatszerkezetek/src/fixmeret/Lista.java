
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fixmeret;

import java.util.ArrayList;

/**
 *
 * @author gyorgy.krisztian
 */
public class Lista {
    public static void main(String[] args) {
        ArrayList<Integer> szamok = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            szamok.add((int)(Math.random()*90)+9);
        }
        szamok.add((int)(Math.random()*44)*2+11);
        kiir(szamok);
    }
    
   static void kiir(ArrayList<Integer> as){
       System.out.println("eredeti");
        for (int object : as) {
            System.out.println(object);
        }
        as.removeIf((sz) -> {
            return sz % 2 == 1 ? true : false;
        });
        System.out.println("Csak páros");
        for (int object : as) {
            System.out.println(object);
        }
        
    }
}


