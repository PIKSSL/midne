package fixmeret;

public class Tombok {

    public static void main(String[] args) {
        int[] sorozat = {3, 5, 1};
        kiirTomb(sorozat);
        valtoztatTomb(sorozat, 0);
        kiirTomb(sorozat);

        int[][] negyzetes = new int[3][5];
        negyzetes[1][2] = 1;
        for (int[] szam : negyzetes) {
            for (int i : szam) {
                System.out.println(i);
            }
            System.out.println("--");
        }
//        kiirTomb(negyzetes[1]);
//        valtoztatTomb(negyzetes[1], 2);
//        kiirTomb(negyzetes[1]);
        System.out.println("FURESZES");
        int[][] fureszes = new int[5][];
        int sordb = fureszes.length;
        for (int i = 0; i < sordb; i++) {
            fureszes[i] = new int[((int) (Math.random() * 5) + 2)];

        }
        for (int[] szam : fureszes) {
            for (int i : szam) {
                System.out.println(i);
            }
            System.out.println("--");
        }

    }

    private static void kiirTomb(int[] tomb) {
        for (int i : tomb) {
            System.out.println(i + "");
        }
        System.out.println("");
    }

    private static void valtoztatTomb(int[] tomb, int index) {
        tomb[index] *= 2;
    }

}
