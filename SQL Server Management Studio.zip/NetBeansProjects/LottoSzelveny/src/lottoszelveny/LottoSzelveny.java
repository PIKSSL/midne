
package lottoszelveny;

import java.util.TreeSet;

public class LottoSzelveny {
        public static final int JO_DB = 5;
        public static final int MAX_SZAM = 90;
    
    public static void main(String[] args) {
        new LottoSzelveny().general();
    }
    
    void general(){
        TreeSet<Integer> szelveny = new TreeSet<>();
        while(szelveny.size()<JO_DB){
            int szam = huzas();
                  szelveny.add(szam);
        }
           for(int szam : szelveny){
                System.out.println(szam);
            }

    }
    
    int huzas(){
        return (int) (Math.random()*MAX_SZAM+1);
    }

}
