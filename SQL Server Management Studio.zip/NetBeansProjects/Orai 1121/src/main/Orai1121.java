package main;

import controller.EmberController;
import model.EmberModel;
import view.ConsoleView;
import view.popupView;

public class Orai1121 {

    public static void main(String[] args) {
        new EmberController(new ConsoleView(), new EmberModel());
//        new EmberController(new popupView(), new EmberModel());
    }

}
