package view;

import java.util.Scanner;

public class ConsoleView extends View{

    private static final Scanner scn = new Scanner(System.in, "ISO-8859-2");

    public ConsoleView() {
    }

    public String input(String str) {
        System.out.print(str);
        String data = scn.nextLine();
        return data;
    }

    public void display() {
        System.out.println(getResult());
    }


//    public void setAge(int age) {
//        this.age = Integer.parseInt(input("Adja meg az életkorát: "));
//    }
//
//    public void setName(String name) {
//        this.name =  input("Adja meg a nevét: ");
//    }

//    @Override
//    public String getNev() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    }
//
//    @Override
//    public int getAge() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    }
}
