package view;

import javax.swing.JOptionPane;


public class popupView extends View{
//    private String result;
    public popupView() {

    }
    
    public String input(String str){
        return JOptionPane.showInputDialog(str);
    }

    public void display() {
        JOptionPane.showConfirmDialog(null,getResult(),"PopUp window",JOptionPane.PLAIN_MESSAGE,JOptionPane.INFORMATION_MESSAGE,null);
    }

//    public void setResult(int age, String name) {
//        result = String.format("%s %d éves", name, age);
//    }
//
//    public String getResult() {
//        return result;
//    }
    
}
