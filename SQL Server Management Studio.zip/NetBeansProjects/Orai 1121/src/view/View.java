package view;

public abstract class View {
    private String result;
    
    public abstract void display();
//    public abstract String getNev();
//    public abstract int getAge();
    public abstract String input(String str);
    
    public void setResult(int age, String name) {
        result = String.format("%s %d éves", name, age);
    }

    public String getResult() {
        return result;
    }
}
