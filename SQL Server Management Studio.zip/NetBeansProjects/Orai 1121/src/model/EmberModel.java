package model;

import java.util.Scanner;

public class EmberModel {

    private String name;
    private int age;

    public EmberModel(String name, int age) {
        setAge(age);
        setName(name);
    }

    public EmberModel() {
        this("noname", 1);
    }

    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setName(String name) {
        this.name = name;
    }

}
