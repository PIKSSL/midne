package controller;

import model.EmberModel;
import view.ConsoleView;
import view.View;
import view.popupView;

public class EmberController {
    public EmberController(View view, EmberModel model) {
         model.setName(view.input("Add meg a neved: "));
        model.setAge(Integer.parseInt(view.input("Add meg az életkorod: ")));
        view.setResult(model.getAge(), model.getName());
        view.display();
    }
    /*
    public EmberController(ConsoleView view, EmberModel model) {
        model.setName(view.input("Add meg a neved: "));
        model.setAge(Integer.parseInt(view.input("Add meg az életkorod: ")));
        view.setResult(model.getAge(), model.getName());
        view.display();
    }
    public EmberController(popupView view, EmberModel model){
        model.setName(view.input("Add meg a neved: "));
        model.setAge(Integer.parseInt(view.input("Add meg az életkorod: ")));
        view.setResult(model.getAge(), model.getName());
        view.display();
    }*/

}
