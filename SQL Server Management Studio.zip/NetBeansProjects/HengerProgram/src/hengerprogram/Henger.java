
package hengerprogram;

public class Henger {
    private static int hengerDarab;
    private double sugar, magassag;
    
    public Henger(double sugar, double magassag){
        this.sugar=sugar;
        this.magassag=magassag;
        this.hengerDarab++;
    }

    public static int getHengerDarab() {
        return hengerDarab;
    }

    public double getSugar() {
        return sugar;
    }

    public double getMagassag() {
        return magassag;
    }

    @Override
    public String toString() {
        return "Henger{" + "sugar=" + sugar + ", magassag=" + magassag + '}';
    }

    
    public double terfogat(){
        return Math.pow(sugar, 2)*Math.PI*magassag;
    }
    
     
   
}
