
package hengerprogram;

public class TomorHenger extends Henger{
    private double fajsuly;
    
    public TomorHenger(double sugar, double magassag, double fajsuly){
        super(sugar, magassag);
        this.fajsuly=fajsuly;
    }
    public TomorHenger(double sugar, double magassag){
        this(sugar, magassag, 0);
        
    }

    public double getFajsuly() {
        return fajsuly;
    }
    
    public double suly(){
        return terfogat()*fajsuly;
    }
    
   

    @Override
    public double terfogat() {
        return super.terfogat(); 
    }
    

    @Override
    public String toString() {
        String os = super.toString();
        return os+"\n\t"+"TomorHenger{" + "fajsuly=" + fajsuly + '}';
    }


   
    
    
}
