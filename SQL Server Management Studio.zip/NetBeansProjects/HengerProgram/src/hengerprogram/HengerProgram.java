
package hengerprogram;

import java.util.ArrayList;
import java.util.List;


public class HengerProgram {
    private List<Henger> hengerek;

    public HengerProgram() {
        hengerek = new ArrayList<>();
        hengerek.add(new Henger(12, 12));
        hengerek.add(new TomorHenger(15, 30));
        hengerek.add(new LyukasHenger(12, 30, 12,12));
    }
    
    public double atlagTerfogat(){
        double atlagV=0;
        for (int i = 0; i < hengerek.size(); i++) {
            atlagV+=hengerek.get(i).terfogat();
        }
        return atlagV/Henger.getHengerDarab();
    }
    
    public double csovekSulya(){
        double csovekSulya=0;
        for (int i = 0; i < hengerek.size(); i++) {
            if(hengerek.get(i) instanceof LyukasHenger)
                csovekSulya+=((LyukasHenger)hengerek.get(i)).suly();
            
        }
        return csovekSulya;
    }
    
    private List lista(){
        return hengerek;
    }
    
    public void run(){
        System.out.println("Hengerek");
        for (Henger henger : hengerek) {
            System.out.println(henger);
        }
        System.out.println("Átlag térfogat: "+atlagTerfogat());
        System.out.println("Csövek súlya: "+csovekSulya());
        
    }
    
    public static void main(String[] args) {
        new HengerProgram().run();
        
    }
    
}
