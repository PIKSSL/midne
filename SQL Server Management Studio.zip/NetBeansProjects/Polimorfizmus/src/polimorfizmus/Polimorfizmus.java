
package polimorfizmus;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JPanel;

public class Polimorfizmus {

    public static void main(String[] args) {
       Object obj1 = new Object();
       JButton btn = new JButton();
       visszaad(obj1);
       visszaad(btn);
        System.out.println("");
//       btn = (JButton) obj1;
       Object obj2 = new JButton();
       btn = (JButton) obj2;
       visszaad(obj2);
       visszaad(btn);
        System.out.println("");
       obj2 = new JPanel();
       visszaad(obj2);
       JPanel jp = (JPanel) obj2;
       visszaad(jp);
//       Object obj3 = new JPanel();
//       JPanel jp = (JPanel) obj3;

    List<Integer> lista = new ArrayList<>();
    List<String> lista2 = new LinkedList<>();
        visszaad(lista);
    }
    
    
    public static void visszaad(Object obj){
        if(obj instanceof JButton){
            System.out.println("Kattintható");
        }else if(obj instanceof JPanel){
            System.out.println("Formázható");
        }else if(obj instanceof List){
            System.out.println("Implementálja a list interfészt");
            if(obj instanceof ArrayList){
                System.out.println("Ez konkrétan egy ArrayList");
            }
            
        }else{
            System.out.println(obj.getClass().getName());
        }
        
    }
}
