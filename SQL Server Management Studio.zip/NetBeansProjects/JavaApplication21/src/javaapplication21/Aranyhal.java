
package javaapplication21;

public class Aranyhal {
    private final static KIVANSAGOKSZAMA = 3;
    
    
}
