
package sorokazasztalon;

import java.util.HashSet;

public class SorokAzAsztalon {

    public static void main(String[] args) {
       new Etterem();

    }
    
}
