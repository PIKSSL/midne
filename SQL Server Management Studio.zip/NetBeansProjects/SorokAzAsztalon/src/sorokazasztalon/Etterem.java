
package sorokazasztalon;

import java.util.ArrayList;
import modell.Asztal;
import modell.Sor;

public class Etterem {
    private ArrayList<Asztal> asztalok;
    public Etterem(){
        asztalok = new ArrayList<>();
        asztalok.add(new Asztal());
        asztalok.add(new Asztal());
        asztalok.add(new Asztal());
        asztalok.add(new Asztal(true));
        asztalok.add(new Asztal(true));
        
        asztalok.get(3).felvesz(new Sor(350,"Dréher"));
        asztalok.get(3).felvesz(new Sor(350,"Borsodi IPA"));
        asztalok.get(3).felvesz(new Sor(999,"Brewdog punkIPA"));
        asztalok.get(3).felvesz(new Sor(550,"Corona"));
        
        asztalok.get(1).felvesz(new Sor(350,"Dréher"));
        asztalok.get(1).felvesz(new Sor(350,"Dréher"));
        asztalok.get(1).felvesz(new Sor(380,"Müller"));
        
        asztalok.get(2).felvesz(new Sor(300,"Aranyászok"));
        asztalok.get(2).felvesz(new Sor(300,"Aranyászok"));
        asztalok.get(2).felvesz(new Sor(300,"Aranyászok"));
        asztalok.get(2).felvesz(new Sor(300,"Aranyászok"));
        
        System.out.println(asztalok.get(3).kimutatas());
        
    }
    
    public void fizetoAsztalok(){
        
    }
    
    
}
