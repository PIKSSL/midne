
package modell;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Asztal {
    private boolean abrosz;
        private ArrayList<Sor> sorok;
    
    public Asztal() {
        this(false);
    }
    
    public Asztal(boolean abrosz){
        this.abrosz = abrosz;
        this.sorok = new ArrayList<>();
    }
    
    public void felvesz(Sor sor){
        this.sorok.add(sor);
    }
    
    public String kimutatas(){
        return tetelek()+"\n"+osszFogyasztas();
    }
    
    public String tetelek(){
        String tetelek = "";
        for (Map.Entry<String, Integer> entry : mibolMennyi().entrySet()) {
            tetelek +="Sör: "+ entry.getKey()+"\nMennyi: "+entry.getValue()+"\n";
        }
        return tetelek;
    }
    
    public int osszFogyasztas(){
        int osszar = 0;
        for (Sor sor : sorok) {
            osszar+=sor.getAr();
        }
        return osszar;
    }
    
    public Map<String, Integer> mibolMennyi(){
        HashMap<String, Integer> mibolMennyi = new HashMap<>();
        for (Sor sor : sorok) {
            String kulcs = sor.getMarka();
            if(mibolMennyi.containsKey(kulcs)){
                int ertek = mibolMennyi.get(kulcs);
                mibolMennyi.put(kulcs, ++ertek);
            }else{
                mibolMennyi.put(kulcs, 1);
            }
        }

        return mibolMennyi;
        }
    
    public void bezarAsztal(){
        sorok.clear();
    }
}
