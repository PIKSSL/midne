
package modell;

public class Sor {
    private int ar;
    private String marka;
    
    public Sor(int ar, String marka){
        this.ar = ar;
        this.marka = marka;
    }
    
    public int getAr(){
        return ar;
    }
    
    public String getMarka(){
        return marka;
    }
    
}
