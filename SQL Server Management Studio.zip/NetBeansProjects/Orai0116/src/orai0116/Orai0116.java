
package orai0116;


import java.net.MalformedURLException;
import java.net.URL;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Orai0116 {

    public static void main(String[] args) throws MalformedURLException {
        new Orai0116().megjelen();
    }
    
    public void megjelen(){
        Icon a = new ImageIcon(this.getClass().getResource("/kepek/unnamed.jpg"));
        JOptionPane.showMessageDialog(null, "hey", "hey", JOptionPane.INFORMATION_MESSAGE, a);
    }
    
}
