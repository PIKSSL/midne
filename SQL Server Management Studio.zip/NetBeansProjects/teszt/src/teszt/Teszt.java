/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package teszt;

import java.io.IOException;
import java.net.Socket;
import java.security.BasicPermission;
import java.util.Random;

/**
 *
 * @author gyorgy.krisztian
 */
public class Teszt {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        //György Krisztián

//Tárolj el egy Gazss eloszlású véletlenszámot

Random rnd = new Random();
double num = rnd.nextGaussian();


////Fejezd be a kódot!
//
String szalNeve = "főSzál";
Thread th = new Thread(szalNeve);

////Hozz létre 3 különböző módon StringBuilder objektumot, sb azonosítóval!
//
StringBuilder sb;
sb = new StringBuilder("Szöveg");
sb = new StringBuilder(5);
sb = new StringBuilder();

Socket sck = new Socket("localhost", 80);

BasicPermission bpm = new BasicPermission("Bpm", "action") {};



    }
    
}
