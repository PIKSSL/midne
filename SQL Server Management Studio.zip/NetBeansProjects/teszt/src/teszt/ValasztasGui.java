
package teszt;

public class ValasztasGui {
    
}
