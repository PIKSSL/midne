
package fajlkezeles;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Asszociativ {

    public static void main(String[] args) throws IOException{
        Path path = Paths.get("fuvar.csv");
        List<String> sorok = Files.readAllLines(path);
        
        String fejlec = sorok.get(0);
        sorok.remove(0);
        List<Fuvar>fuvartarolo = new ArrayList<Fuvar>();
        for (String sor : sorok) {
            fuvartarolo.add(new Fuvar(sor.replace(',', '.')));
        }
        Map<String,Integer> mibolMennyi = new HashMap<>();
        for (Fuvar fuvar : fuvartarolo) {
            String kulcs = fuvar.getFizetesi_mod();
            if(mibolMennyi.containsKey(kulcs)){
                int ertek = mibolMennyi.get(kulcs);
                mibolMennyi.put(kulcs, ++ertek);
            }else{
                mibolMennyi.put(kulcs, 1);
            }
        }
        kiir(mibolMennyi);
    }

    private static void kiir(Map<String, Integer> mibolMennyi) {
        for (Map.Entry<String, Integer> entry : mibolMennyi.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();
            System.out.println(key+" "+value);
            
        }
    }
    
}
