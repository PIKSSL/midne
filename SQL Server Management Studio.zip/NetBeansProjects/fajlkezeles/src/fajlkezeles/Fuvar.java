/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fajlkezeles;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Fuvar {

    private int taxi_id, idotartam;
    private double tavolsag, viteldij, borravalo;
    private String fizetesi_mod, indulas;
    private static String separator = ";";

//    public Fuvar(String taxi_id, int idotartam, Date datum, double tavolsag, double viteldij, double borravalo, String fizetesi_mod) {
//        setTaxi_id(taxi_id);
//        setIdotartam(idotartam);
//        setDatum(datum);
//        setTavolsag(tavolsag);
//        setViteldij(viteldij);
//        setBorravalo(borravalo);
//        setFizetesi_mod(fizetesi_mod);
//        
//    }
    public Fuvar(String fuvar) {
        this(fuvar, separator);
    }

    public Fuvar(String fuvar, String sep) {
        String[] adatok = fuvar.split(sep);
        setTaxi_id(adatok[0]);
        setIndulas(adatok[1]);
        setIdotartam(adatok[2]);
        setTavolsag(adatok[3]);
        setViteldij(adatok[4]);
        setBorravalo(adatok[5]);
        setFizetesi_mod(adatok[6]);

    }

    public void setTaxi_id(String taxi_id) {
        this.taxi_id = Integer.parseInt(taxi_id);
    }

    public void setIdotartam(String idotartam) {
        this.idotartam = Integer.parseInt(idotartam);
    }

    public void setIndulas(String indulas) {

        this.indulas = indulas;
    }

    public String getFizetesi_mod() {
        return fizetesi_mod;
    }

    public void setTavolsag(String tavolsag) {
        this.tavolsag = Double.parseDouble(tavolsag);
    }

    public void setViteldij(String viteldij) {
        this.viteldij = Double.parseDouble(viteldij);
    }

    public void setBorravalo(String borravalo) {
        this.borravalo = Double.parseDouble(borravalo);
    }

    public void setFizetesi_mod(String fizetesi_mod) {
        this.fizetesi_mod = fizetesi_mod;
    }

    public static void hanyfeleFizetes(List<Fuvar> lista) {
        Set<String> hanyFele = new TreeSet<>();
        Set<String> hanyFeleH = new HashSet<>();

        for (Fuvar fm : lista) {
            hanyFele.add(fm.getFizetesi_mod());
            hanyFeleH.add(fm.getFizetesi_mod());
        }
        System.out.println("EREDETI:");
        for (String string : hanyFeleH) {
            System.out.println(string);
        }
        System.out.println("");
        System.out.println("RENDEZETT:");
        for (String string : hanyFele) {
            System.out.println(string);
        }
    }
}
