    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package fajlkezeles;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 *
 * @author gyorgy.krisztian
 */
public class Fajlkezeles {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException{
        Path path = Paths.get("fuvar.csv");
        List<String> sorok = Files.readAllLines(path);
        
        String fejlec = sorok.get(0);
        sorok.remove(0);
        List<Fuvar>fuvartarolo = new ArrayList<Fuvar>();
        for (String sor : sorok) {
            fuvartarolo.add(new Fuvar(sor.replace(',', '.')));
        }
        Fuvar.hanyfeleFizetes(fuvartarolo);
        }
}
