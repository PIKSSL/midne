
package fajlkezeles;
public class Ember {
    private String name,address;
    private int age;
    private static String separator = ":";
    public Ember(String name, String address, int age) {
        this.name = name;
        this.address = address;
        this.age = age;
    }
    
    public Ember(String sor){
        this(sor, separator);
    }
        
    public Ember(String sor, String sep){
        String[] adat = sor.split(sep);
        this.name = adat[0];
        this.address = adat[1];
        this.age = Integer.parseInt(adat[2]);
    }

    
    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public int getAge() {
        return age;
    }

    public static String getSeparator() {
        return separator;
    }

    
}
