
package fajlkezeles;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AsszociativOsszetett {
    public static void main(String[] args) {
        HashMap<String, Double> nevekAtlaggal = new HashMap<>();
        nevekAtlaggal.put("Pál", 4.50);
        nevekAtlaggal.put("Ede", 3.50);
        
        HashMap<String, ArrayList<Integer>> nevekJegyekkel = new HashMap<>();
        ArrayList<Integer> jegyek = new ArrayList<>();
        jegyek.add(5);
        jegyek.add(2);
        jegyek.add(4);
        jegyek.add(3);
        nevekJegyekkel.put("Pál", jegyek);
        nevekJegyekkel.put("Ede", jegyek);
        jegyek.set(0, 1);
        kiir(nevekJegyekkel);
    }
    
        private static void kiir(Map<String, ArrayList<Integer>> mibolMennyi) {
        for (Map.Entry<String, ArrayList<Integer>> entry : mibolMennyi.entrySet()) {
            String key = entry.getKey();
            System.out.println(key+" jegyei:");
            ArrayList<Integer> value = entry.getValue();
            System.out.println(key+" "+value);
            for (Integer jegy : value) {
                System.out.println(jegy+"");
            }
            
        }
            System.out.println("Pál egy csira \n");
    }
}