use ugyfelszolg

--adott napon h�ny mos�g�pet adtak el?
--adott cikkb�l �vente h�ny csere t�rt�nt?
--2 adott d�tum k�z�tt mekkora lett �rbev�tel?
--adott csere h�ny nappal az elad�s ut�n t�rt�nt?
--adott napon milyen cikkeket fizettek vissza?

select * from CIKK
select * from CSERE
select * from ELAD�S
select * from TERM�K
select * from VISSZAFIZ

create function mosomaci
(
@napon date
)
returns int
begin
declare @vissza int
set @vissza = (select COUNT(*) from ELAD�S e inner join TERM�K t on e.cikksz�m = t.cikksz�m inner join CIKK c on t.cikksz�m = c.cikksz�m where c.megnev = 'mos�g�p' and e.kelt = @napon)
return @vissza
end


create function hany_csere_tortent
(
@cikk char
)
returns table
return (select year(d�tum1) as �ven, count(*) as h�ny from CSERE where cikksz�m = @cikk group by year(d�tum1))

select * from dbo.hany_csere_tortent('c333')
select dbo.mosomaci('2022-10-24') as h�ny


create function bevetel
(
@kezd date,
@veg date
)
returns int
begin
return (select sum(�r) from ELAD�S where kelt>=@kezd and kelt<=@veg)
end

select dbo.bevetel('2015-01-03','2025-01-01')