create function mosomaci
(
@napon date
)
returns int
begin
declare @vissza int
set @vissza = (select COUNT(*) from ELAD�S e inner join TERM�K t on e.cikksz�m = t.cikksz�m inner join CIKK c on t.cikksz�m = c.cikksz�m where c.megnev = 'mos�g�p' and e.kelt = @napon)
return @vissza
end

go
create function hany_csere_tortent
(
@cikk char
)
returns table
return (select year(d�tum1) as �ven, count(*) as h�ny from CSERE where cikksz�m = @cikk group by year(d�tum1))

go
create function bevetel
(
@kezd date,
@veg date
)
returns int
begin
return (select sum(�r) from ELAD�S where kelt>=@kezd and kelt<=@veg)
end