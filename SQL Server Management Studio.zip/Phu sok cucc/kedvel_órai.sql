create database kedvel

use kedvel


create table szem�ly
(
azon int identity(100,1),
n�v varchar(20),
-- szd�tum, n�vnap
-- viszony (saj�t nyt),
primary key (azon)
)

create table sz�t�r
(
id int identity(1,1),
�rt�k char(30),
t�pus char(1),
primary key (id),
unique (�rt�k, t�pus)
)

create table dolog
(
dk�d int identity(495,10),
elnevez�s varchar(30),
besorol�s int, --sz�t�razott
primary key (dk�d)
)

create table term�k
(
tk�d int identity(500,10),
jellemz� int,--sz�t�razott
m�rka int, --sz�t�razott
dolog int,
-- megnev... 
primary key (tk�d),
foreign key (dolog) references dolog (dk�d)
)

create table kedvel
(
szem�ly int,
term�k int,
m�rt�k tinyint, -- 0-5
primary key (szem�ly, term�k),
foreign key (szem�ly) references szem�ly (azon),
foreign key (term�k) references term�k (tk�d)
)


alter table sz�t�r
add constraint CK_szotar check (t�pus='B' or t�pus='J' or t�pus='M'  )

alter table kedvel
add constraint ck_kedvel check (m�rt�k between 0 and 5)

alter table szem�ly
add unique (n�v)

alter table sz�t�r
add unique (�rt�k, t�pus)
go

create proc kedv_felv
-- param�terei k�z�l a jellemz� �s m�rka �rt�ke lehet '---' ami az �sszesf�le
	@sz_neve varchar(20), 
	@j_�rt�k char(30), 
	@m_�rt�k char(30), 
	@d_elnev varchar(30), 
	@m�rt�k tinyint

as
begin
	if @sz_neve is null or @j_�rt�k is null or @m_�rt�k is null 
		or @d_elnev is null or @m�rt�k is null
		print 'ki kell t�lteni mindet; ha a jellemz� vagy a m�rka tetsz�leges, legyen ---'
	else
	begin
	declare @azon int, @dk�d int, @tk�d int
	declare @jid int, @mid int
	-- az akt. gen. kulcsoknak
	select @azon=azon from szem�ly where n�v=@sz_neve
	if @azon is null
		begin
			insert into szem�ly values (@sz_neve)
			set @azon=ident_current('szem�ly')
		end
	select @dk�d=dk�d from dolog where elnevez�s=@d_elnev
	if @dk�d is null
		begin
			insert into dolog values (@d_elnev, null)
			set @dk�d=ident_current('dolog')
		end

	select @jid=id from sz�t�r where �rt�k=@j_�rt�k
	if @jid is null
		begin
			insert into sz�t�r values (@j_�rt�k, 'J')
			set @jid=ident_current('sz�t�r')
		end
	
	select @mid=id from sz�t�r where �rt�k=@m_�rt�k
	if @mid is null
		begin
			insert into sz�t�r values (@m_�rt�k, 'M')
			set @mid=ident_current('sz�t�r')
		end
	
	select @tk�d=tk�d from term�k
	where dolog=@dk�d and jellemz�=@jid and m�rka=@mid
	if @tk�d is null
		begin
			insert into term�k values (@jid, @mid, @dk�d)
			set @tk�d=ident_current('term�k')
		end
	insert into kedvel 
	values (@azon, @tk�d, @m�rt�k)
	-- a kulcs �s a m�rt�k a constr-re b�zva
	end
end
--update szem�ly
--set n�v='Gy�rgy Kriszti�n'
--where n�v='Krisz'
--adatok

--exec kedv_felv 'Moln�r Szabrina', 'mazsol�s', '---', 'csoki', 1
--exec kedv_felv 'Gy�rgy Kriszti�n','vastag','Pikk','Szal�mi',3
--exec kedv_felv 'Gy�rgy Kriszti�n','mechanikus','Logitech','Billenty�zet',5
--exec kedv_felv 'Gy�rgy Kriszti�n','piros','Akko','Switchk�szlet',3
--exec kedv_felv 'Gy�rgy Kriszti�n','Marshmallow sz�n�','Akko','Keycapk�szlet',5
--exec kedv_felv 'Gy�rgy Kriszti�n','Nagym�ret�','Krytox','lube',5
--exec kedv_felv 'Gy�rgy Kriszti�n','Szines','---','sapka',1
--exec kedv_felv 'P. Krist�f', 'sz�nes', 'Stabilo', 'ceruza', 2
--exec kedv_felv 'P. Krist�f', 'feh�r', '---', 'h�g�mb', 5
--exec kedv_felv 'P. Krist�f', 'szarvasos', '---', 'k�t�tt pulcsi', 5
--exec kedv_felv 'P. Krist�f', 'kar�csonyos', '---', 'b�gre', 3
--exec kedv_felv 'Weinberger P�ter', 'feh�r', 'Lindt', 'csoki', 5
--exec kedv_felv 'Weinberger P�ter', 'RS 7', 'Audi', 'aut�', 5
--exec kedv_felv 'Weinberger P�ter', 'k�rtel�', 'Si�', '�dit�', 2
--exec kedv_felv 'Weinberger P�ter', 'mazsol�s', '---', '�tel', 1
--exec kedv_felv 'Weinberger P�ter', '�des', 'Varga', 'bor', 3
--exec kedv_felv 'Xu Jiyu', '�t', '---', 'csoki', 5
--exec kedv_felv 'Xu Jiyu', 'pomelo', '---', 'gy�m�lcs', 5
--exec kedv_felv 'Xu Jiyu', 'mechanikus billenty�zet', 'Razer', 'informatikai kieg', 5
--exec kedv_felv 'Xu Jiyu', 'rtx 4090', 'Nvidia', 'informatikai kieg', 5
--exec kedv_felv 'Xu Jiyu', 'tej', 'Milka', 'csoki', 1
--exec kedv_felv 'Xu Jiyu', 'vodka', '---',  't�m�ny', 1
--exec kedv_felv 'Csisz�r Dominik', 'K�kuszos', 'Milka', 'Csokol�d�', 3
--exec kedv_felv 'Csisz�r Dominik', 'M3', 'BMW', 'Aut�', 5
--exec kedv_felv 'Csisz�r Dominik', 'Edz�s', 'T�r�kb�lint Ar�na', 'B�rlet', 5
--exec kedv_felv 'Csisz�r Dominik', 'Marcip�nos', 'Boci', 'Csokol�d�', 4
--exec kedv_felv 'Csisz�r Dominik', 'Sampon', 'B�rmilyen', 'Illatszer', 2
--exec kedv_felv 'Csisz�r Dominik', 'Illat', 'B�rmilyen', 'Gyertya', 1
--exec kedv_felv 'Pa�l �d�m','maxi king', 'kinder','csoki', 5
--exec kedv_felv 'Pa�l �d�m', 't�kf�zel�k', 'otthoni','f�zel�k', 1
--exec kedv_felv 'Pa�l �d�m','nutella', 'Ferrero', 'Mogyor� k�rm',5
--exec kedv_felv 'Vet�si Gy�rgy �d�m', 'Fekete A8','Audi','Aut�',5
--exec kedv_felv 'Vet�si Gy�rgy �d�m','�zes�tett s�r','---','S�r',5
--exec kedv_felv 'Vet�si Gy�rgy �d�m','Tej','---','Csoki',3
--exec kedv_felv 'Vet�si Gy�rgy �d�m','Kulcstart�','---','Kacat',4
--exec kedv_felv 'Somosk�i G�bor', 'Travis Scott', '---', 'el�ad�', 5
--exec kedv_felv 'Somosk�i G�bor', 'illatos', '---', 'gyertya', 4
--exec kedv_felv 'Somosk�i G�bor', 'mogyor�s', 'Ritter Sport', 'feh�r csoki', 4
--exec kedv_felv 'Somosk�i G�bor', 'm�zes', 'Arizona', 'tea', 4
--exec kedv_felv 'Somosk�i G�bor', '---', '---', 'felvarr�', 4
--exec kedv_felv 'Polg�r Attila', 'kal�csos', '---', 'csoki', 2
--exec kedv_felv 'Polg�r Attila', 'sajtos', '---', 'r�g�', 3
--exec kedv_felv 'Polg�r Attila', 'p�rk�ltes', '---', 'gumicukor', 4
--exec kedv_felv 'Polg�r Attila', 'spen�tos', '---', 'fagyi', 5
--exec kedv_felv 'Polg�r Attila', 'boros', '---', 'keny�r', 2
--exec kedv_felv 'Roh�csi Daniella', 'Born In Roma Donna', 'Valentino', 'parf�m', 5
--exec kedv_felv 'Roh�csi Daniella', 'mogyor�s', 'Milka', 'csoki', 3
--exec kedv_felv 'Roh�csi Daniella', '---', 'Csoki-Du�', 't�li fagyi', 3
--exec kedv_felv 'Roh�csi Daniella', '---', 'Retro', 't�li fagyi', 0
--exec kedv_felv 'Roh�csi Daniella', '---', '---', 'virslis t�ska', 5
--exec kedv_felv 'Rohovszky �kos', 'narancsos', '---', 'csoki', 1
--exec kedv_felv 'Rohovszky �kos', 'szal�mi', '---', 'felv�gott', 3
--exec kedv_felv 'Rohovszky �kos', '60%', 'Boci', 'csoki', 5
--exec kedv_felv 'Rohovszky �kos', 'tej', '---', 'csoki', 2
--exec kedv_felv 'Rohovszky �kos', 'trapista', '---', 'sajt', 5
--exec kedv_felv 'Vitay Zal�n', 'mang�s', 'Monster', 'energiaital', 5
--exec kedv_felv 'Vitay Zal�n', 'original', 'Monster', 'energiaital', 5
--exec kedv_felv 'Vitay Zal�n', 'mazsol�s', '---', 'csoki', 1
--exec kedv_felv 'Vitay Zal�n', 'speedcube', '---', 'rubik kocka', 5
--exec kedv_felv 'Vitay Zal�n', 'epres', 'Milka', 'csoki', 5
--exec kedv_felv 'Vitay Zal�n', 'sajtos-ketchupos', 'Cheetos', 'chips', 5
--exec kedv_felv 'Vitay Zal�n', 'doctor', 'Monster', 'energiaital', 1
--exec kedv_felv 'Vitay Zal�n', 'Supra mk4', 'Toyota', 'auto', 5
--exec kedv_felv 'Vitay Zal�n', 'RX7', 'Mazda', 'auto', 5
--exec kedv_felv 'Szedl�r Krisztina','Illatgyetya','Pepco','Gyertya',5
--exec kedv_felv 'Szedl�r Krisztina','Izes�tett vodka','Absolut','Alkohol',5
--exec kedv_felv 'Szedl�r Krisztina','Koncertutalv�ny','-','Utalv�ny',5
--exec kedv_felv 'Szedl�r Krisztina','Mazsol�s csoki','-','Csoki',1
--exec kedv_felv 'Szundi Kata', 'narancsos', '---', 'torta', 2
--exec kedv_felv 'Szundi Kata', 'f�z�sre val�', '---', 'j�t�kkonyha', 4
--exec kedv_felv 'Szundi Kata', 'enegri�t ad', 'Monster', 'energia ital', 3
--exec kedv_felv 'Szundi Kata', 'nagy kijelz�s', 'Samsung', 'monitor', 5
--exec kedv_felv 'Szundi Kata', 'hideg', '---', 'rakott krumpli', 1
--exec kedv_felv 'Szundi Kata', 'finom', 'Nagyi f�le', 'bors� leves', 5
--exec kedv_felv 'Katona J�nos','Ropog�s','Doll�r','P�nz', 5
--exec kedv_felv 'Katona J�nos','mogyis','Roshen','Csoki', 4
--exec kedv_felv 'Katona J�nos','eaude','jean paul gaultier','parfum', 5
--exec kedv_felv 'Katona J�nos','Terre d Parfum','Hermes','parfum', 5
--exec kedv_felv 'Katona J�nos','k�kuszos','illat','gyertya', 2
--exec kedv_felv 'Gy�rgy Kriszti�n','---','---','csoki',3
--exec kedv_felv 'Katona J�nos','---','Roshen','Csoki', 5
--delete from kedvel where szem�ly=100 and term�k=540
--delete from term�k where tk�d=540 
--delete from sz�t�r where id=6
--insert into sz�t�r values('j�rm�','B')
--insert into sz�t�r values('h�ztart�si kieg�sz�t�','B')
--insert into sz�t�r values('�r�szer','B')
--insert into sz�t�r values('lak�sd�sz','B')
--insert into sz�t�r values('sportkell�k','B')
--insert into sz�t�r values('elektronikai eszk�z','B')
--insert into sz�t�r values('fizet�eszk�z','B')

select * from sz�t�r
select * from dolog
select * from term�k
select * from kedvel
select * from szem�ly



--insert into sz�t�r values ('ital','B')
--insert into sz�t�r values ('�dess�g','B')
--insert into sz�t�r values ('kult�ra','B')
--insert into sz�t�r values ('szg. tartoz�k','B')
--insert into sz�t�r values ('ruhanem�','B')
--insert into sz�t�r values ('kozmetika','B')
--insert into sz�t�r values ('�tel','B')
--insert into sz�t�r values ('gy�m�lcs','B')

--select * from term�k where dolog=505
--select *from sz�t�r order by id

--update dolog 
--set elnevez�s='pomelo'
--where dk�d=645
--update term�k set jellemz�=15 where tk�d=510
