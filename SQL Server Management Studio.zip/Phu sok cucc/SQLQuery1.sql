--use master; drop database gyorsetterem
create database gyorsetterem
go
use gyorsetterem
go

create table osszetevo
(
oszt_azon int identity(1,1) not null,
elnevezes char(30) not null,
laktozmentes bit default(0),
vegan bit default(0),
glutenmentes bit default(0),
mogyoromentes bit default(0),
primary key(oszt_azon)
)

create table etel_ital
(
ei_azon int identity(1,1) not null,
elnevezes char(30) not null,
kategoria  char(2) not null,
primary key(ei_azon)
)


create table termek
(t_azon int identity(1, 1),
etel_ital int not null,
kiszereles char(7),
ar money not null,
jelleg char(1) not null
primary key (t_azon)
)

create table recept
(
termek int,
osszetevo int,
mennyiseg int default(0)
primary key (termek, osszetevo)
)

create table menu_tetel
(
menu int,
termek int,
mennyiseg int not null,
primary key (menu,termek)
)

create table penztar
(
p_azon int identity(1,1),
megnevezes char(30) not null,
primary key (p_azon)
)

create table RENDELES
(
	rend_szam int identity(1,1),
	idopont date default(getdate()), -- de ezt mindj�rt megn�zz�k hogy kell
	penztar int not null,
	statusz char(1) not null
    primary key (rend_szam)
)

create table RENDELES_TETEL
(
	rend_szam int not null,
	termek int not null,
	mennyiseg int not null
    primary key (rend_szam, termek)
)

create table munkakor
(
m_azon int identity (1,1),
megnevezes char(30) not null,
primary key(m_azon)
)

create table dolgozo
(
d_azon int identity(1,1),
nev char(30) not null,
munkakor int,
belepett date not null,
kilepett date,    
primary key(d_azon)
)

create table muszak(
msz_azon int identity(1, 1),
mettol tinyint not null,
meddig tinyint not null
primary key (msz_azon)
)

create table dolgozik
(
datum date not null,
dolgozo int not null,
muszak int not null,
penztar int,
primary key(datum,dolgozo)
)

alter table menu_tetel
add foreign key (menu) references termek (t_azon),
    foreign key (termek) references termek (t_azon)

alter table termek
add foreign key (etel_ital) references etel_ital (ei_azon)

alter table recept
add foreign key (osszetevo) references osszetevo (oszt_azon)

alter table rendeles
add foreign key (penztar) references penztar (p_azon)

alter table rendeles_tetel
add foreign key (termek) references termek (t_azon),
    foreign key (rend_szam) references rendeles (rend_szam)

alter table dolgozo
add foreign key (munkakor) references munkakor (m_azon)

alter table dolgozik
add foreign key (dolgozo) references dolgozo (d_azon),
    foreign key (muszak) references muszak (msz_azon),
    foreign key (penztar) references penztar (p_azon)

create function jelleg(
@menu int,
@solo int
)
returns bit

begin
declare @vissza bit
if ((select jelleg from termek where t_azon = @menu)='M' and (select jelleg from termek where t_azon = @solo)='S')
	set @vissza = 1
else
	set @vissza = 0
return @vissza
end

alter table menu_tetel
add check (dbo.jelleg(menu,termek)=1)

create function dolgozo_kilepett
(
@belepett date,
@kilepett date
)
returns bit
begin
declare @vissza bit
if(@kilepett is not null)
	if(@kilepett >@belepett)
		set @vissza = 1
	else
		set @vissza = 0
else
	set @vissza = 1
return @vissza
end

alter table dolgozo
add check (dbo.dolgozo_kilepett(belepett, kilepett)=1)

