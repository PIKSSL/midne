package main;

import nezet.SwDlgGUINezet;
import modell.EmberModell;
import nezet.SwDlgKodNezet;
import nezet.JopNezet;
import nezet.KonzolNezet;
import vezerlo.Vezerlo;

public class Program {

    public static void main(String[] args) {
        //new Vezerlo(new EmberModell(0, ""), new KonzolNezet());
        //new Vezerlo(new EmberModell(), new KonzolNezet());
        
        //new Vezerlo(new EmberModell(0, ""), new JopNezet());
//        Megjelenites nezet = new Megjelenites();
        SwDlgKodNezet nezet = new SwDlgKodNezet();
        
        new Vezerlo(new EmberModell(), nezet);
        
        
        /* TESZT & DEBUG nézet tesztelésére */
            /* 1. eset, nincs hiba */
            /* 2. eset, nem lehet nevet bekérni */
        /* TESZT & DEBUG vége */
        
    }
    
}
