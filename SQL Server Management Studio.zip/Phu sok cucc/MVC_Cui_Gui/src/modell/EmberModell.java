package modell;

public class EmberModell {
    private int kor;
    private String nev;

    public EmberModell() {
        this(1, "nincs név");
    }

    public EmberModell(int kor, String nev) {
        this.kor = kor;
        this.nev = nev;
    }

    public int getKor() {
        return kor;
    }

    public void setKor(int kor) {
        this.kor = kor;
    }

    public String getNev() {
        return nev;
    }

    public void setNev(String nev) {
        this.nev = nev;
    }
    
    
}
