package vezerlo;

import nezet.SwDlgGUINezet;

import modell.EmberModell;
import nezet.SwDlgKodNezet;
import nezet.JopNezet;
import nezet.KonzolNezet;
import nezet.View;

public class Vezerlo {
    /* ez most nem is kell, csak több tagfüggvénynél */
    //private EmberModell modell;
    //private KonzolNezet konzolNezet;

    public Vezerlo(EmberModell modell, View nezet) {
        // ez most nem is kell, csak több tagfüggvénynél
        //this.modell = modell;
        //this.konzolNezet = konzolNezet;
        
        //modell beállítása a nézetből
        
        modell.setKor(nezet.getKor());
        modell.setNev(nezet.getNev());
        
        //nézetben megjelenítés
        nezet.setEredmeny(modell.getKor(), modell.getNev());
        
        nezet.megjelenit();
    }
    public Vezerlo(EmberModell modell, SwDlgGUINezet nezet){
        nezet.getGomb().addActionListener((e) -> {
            modell.setNev(nezet.getNev());
            modell.setKor(nezet.getKor());
            nezet.megjelenit("neve: "+modell.getNev()+" kora: "+modell.getKor());
        });
    }
    public Vezerlo(EmberModell modell, SwDlgKodNezet nezet){
            nezet.getGomb().addActionListener((e) -> {
            modell.setNev(nezet.getNev());
            modell.setKor(nezet.getKor());
            nezet.megjelenit("neve: "+modell.getNev()+" kora: "+modell.getKor());
        });
    }
    
    /*
    public Vezerlo(EmberModell modell, KonzolNezet konzolNezet) {
        // ez most nem is kell, csak több tagfüggvénynél
        //this.modell = modell;
        //this.konzolNezet = konzolNezet;
        
        //modell beállítása a nézetből
        modell.setKor(konzolNezet.getKor());
        modell.setNev(konzolNezet.getNev());
        
        //nézetben megjelenítés
        konzolNezet.setEredmeny(modell.getKor(), modell.getNev());
        konzolNezet.megjelenit();
    }
    
    public Vezerlo(EmberModell modell, JopNezet jopNezet) {
        // ez most nem is kell, csak több tagfüggvénynél
        //this.modell = modell;
        //this.konzolNezet = konzolNezet;
        
        //modell beállítása a nézetből
        modell.setKor(jopNezet.getKor());
        modell.setNev(jopNezet.getNev());
        
        //nézetben megjelenítés
        jopNezet.setEredmeny(modell.getKor(), modell.getNev());
        jopNezet.megjelenit();
    }
    */
}
