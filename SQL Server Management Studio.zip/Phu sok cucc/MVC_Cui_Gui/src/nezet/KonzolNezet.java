package nezet;

import java.util.Scanner;

public class KonzolNezet extends View{
    
    //private static final Scanner sc = new Scanner(System.in, "iso-8859-2");
    private static final Scanner sc = new Scanner(System.in, "latin2");
    
    //private String eredmeny;
    
    @Override
    public int getKor() {
        System.out.print("kor: ");
        int kor = sc.nextInt();
        sc.nextLine();//szám utáni ENTERt kiolvassa
        return kor;
    }
    
    @Override
    public String getNev() {
        System.out.print("név: ");
        return sc.nextLine();
    }
    
    /* egyszerű megoldás */
    @Override
    public void megjelenit(String szoveg){
        System.out.println(szoveg);
    }
    
    /* részletes */
//    public void setEredmeny(int kor, String nev){
//        eredmeny = String.format("%s %d éves", nev, kor);
//    }
//    
//    public String getEredmeny(){
//        return eredmeny;
//    }
    
    @Override
    public void megjelenit(){
        //System.out.println(eredmeny);
        System.out.println(getEredmeny());//ősben van
        
        
        /* TESZT & DEBUG */
//        int kor = getKor();
//        String nev = getNev();
//        System.out.printf("%s %d éves", nev, kor);
        /* TESZT & DEBUG vége */
    }
    
    /* TESZT & DEBUG vagy a main()-ben is lehetne */
//    public static void main(String[] args) {
//        KonzolNezet n = new KonzolNezet();
//        /* 1. eset, nincs hiba */
//        //n.getNev();
//        //n.getKor();
//        
//        /* 2. eset, nem lehet nevet bekérni */
//        //n.getKor();
//        //n.getNev();
//        
//        /* 3. eset, nem tud megjeleníteni 
//           4. eset, hibás az ékezet
//        */
//        n.megjelenit();
//    }
    /* TESZT & DEBUG vége */
    
}
