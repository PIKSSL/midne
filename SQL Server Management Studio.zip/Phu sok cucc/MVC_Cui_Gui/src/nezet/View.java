package nezet;

public abstract class View {
    
    private String eredmeny;
    
    public abstract int getKor();
    
    public abstract String getNev();
            
    public abstract void megjelenit();
            
    public abstract void megjelenit(String szoveg);
    
    /* részletes */
    public void setEredmeny(int kor, String nev){
        eredmeny = String.format("%s %d éves", nev, kor);
    }
    
    public String getEredmeny(){
        return eredmeny;
    }
}
