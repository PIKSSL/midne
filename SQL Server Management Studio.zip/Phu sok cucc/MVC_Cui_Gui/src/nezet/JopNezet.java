package nezet;

import javax.swing.JOptionPane;

public class JopNezet extends View{
    
    //private String eredmeny;
    
    @Override
    public int getKor() {
        String s = JOptionPane.showInputDialog("kor: ");
        return Integer.parseInt(s);
    }
    
    @Override
    public String getNev() {
        return JOptionPane.showInputDialog("név: ");
    }
    
    /* egyszerű megoldás */
    @Override
    public void megjelenit(String szoveg){
        //JOptionPane.showMessageDialog(null, szoveg);
        JOptionPane.showMessageDialog(JOptionPane.getRootFrame(), szoveg);
    }
    
    /* részletes */
//    public void setEredmeny(int kor, String nev){
//        eredmeny = String.format("%s %d éves", nev, kor);
//    }
//    
//    public String getEredmeny(){
//        return eredmeny;
//    }
    
    @Override
    public void megjelenit(){
        //JOptionPane.showMessageDialog(JOptionPane.getRootFrame(), eredmeny);
        JOptionPane.showMessageDialog(JOptionPane.getRootFrame(), getEredmeny());
    }
}
