/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nezet;

import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author gyorgy.krisztian
 */
public class SwDlgKodNezet {
    
    JDialog jd;
    JLabel jl1;
    JTextField f1;
    JTextField f2;
    JButton jb;
    

    public SwDlgKodNezet() {
        JDialog jd = new JDialog();
        jd.setSize(new Dimension(300, 200));
        jd.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        jd.setLayout(new GridLayout(3,2,10,0));
        
        

        f1 = new JTextField();
        f2 = new JTextField();
        jl1 = new JLabel("Eredmény: ");
        jb = new JButton("ok");
        
        jd.add(new JLabel("Név:"));
        jd.add(f1);
        jd.add(new JLabel("Kor:"));
        jd.add(f2);
        jd.add(jl1);
        jd.add(jb);
        jd.setVisible(true);
    }
    public int getKor() {
        return Integer.parseInt(f2.getText());
    }
    public String getNev() {
        return f1.getText();
    }
    public void megjelenit(String szoveg){
        jl1.setText("Eredmény: "+szoveg);
    }
    public JButton getGomb(){
        return jb;
    }
    
    
}
