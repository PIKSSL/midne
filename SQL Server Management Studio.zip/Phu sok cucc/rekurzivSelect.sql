create database random 
use random

-- A with-select kiz�r�lag a UNION ALL-al oldhat� meg (pl. connect by...)
create table dolgozo
(
k�d int identity,
n�v varchar,
f�n�k int,
primary key (k�d)
) 


-- kockasz�mok legener�l�s
with kocka (sz�m)
as
(
select 1 --as sz�m
union all
select sz�m+1
from kocka 
where sz�m<6
)
select * from kocka 




-- 2 kock�val minden elemi esem�ny
with kocka (sz�m)
as
(
select 1 --as sz�m
union all
select sz�m+1
from kocka 
where sz�m<6
)
select * from kocka e, kocka m
-- select COUNT(*) from kocka e, kocka m
-- select * into #egyik from kocka
-- select * from #egyik, #egyik as m�sik


go


-- j�l olvashat� tipik. 2-l�p�ses lek�rd.

with els�_l�p�s (anyag, ennyiszer)
as
(
select azonos�t�, count(*) 
from beszerz�s
group by azonos�t�
)
select * from els�_l�p�s 
where ennyiszer=(select max(ennyiszer) from els�_l�p�s)


go

-- De a rekurz�v lek�rdez�s a l�nyege:


-- select * from dolgoz� 
--create table dolgoz�
--(
--k�d int, n�v varchar(30), f�n�k int,
--primary key (k�d), foreign key (f�n�k) references dolgoz� (k�d)
--)

insert into dolgozo
values('Elek Andr�s')

create view hierarchia 

as

with hierarchia (dolgoz�, f�n�ke, szint)
as
(
select k�d, f�n�k, 1 as szint
from dolgoz� 
where f�n�k is null
union all
select k�d, f�n�k, szint+1
from dolgoz�, hierarchia
where dolgoz�=f�n�k
)
select * from hierarchia
--select count(distinct szint) from hierarchia
-- vagy select count(*) from hierarchia
-- vagy kimentve tov. felhaszn.
-- select * into szintek from hierarchia
-- select * from szintek


