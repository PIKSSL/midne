import KonyvController from "./Controller/KonyvController.js";
import KosarController from "./Controller/KosarController.js";

$(function() {
    new KonyvController();
    new KosarController();
});