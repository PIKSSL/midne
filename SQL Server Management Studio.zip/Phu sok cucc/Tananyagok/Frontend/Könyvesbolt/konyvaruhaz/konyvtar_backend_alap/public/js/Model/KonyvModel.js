class KonyvModel {
    #konyvekTomb = [];
    #konyvekTombB = [];
    constructor(token) {
        this.token = token;     
    }

    adatModosit(vegpont,data) {
        console.log(data.id);
        vegpont +="/"+data.id;
        console.log(vegpont);
        fetch(vegpont, {
            method: 'PUT',
            headers:{
                "X-CSRF-TOKEN": this.token,
            },
        })
        .then()
        .then(()=>{
            console.log("sikeres törlés");
        })
        .catch((error)=>{
            console.error("Error:",error);
        });
    }
    adatTorol(vegpont,data) {
        console.log(data.id);
        vegpont +="/"+data.id;
        console.log(vegpont);
        fetch(vegpont, {
            method: 'DELETE',
            headers:{
                "X-CSRF-TOKEN": this.token,
            },
        })
        .then()
        .then(()=>{
            console.log("sikeres törlés");
        })
        .catch((error)=>{
            console.error("Error:",error);
        });
    }

    getKonyvek(){
        return this.#konyvekTomb;
    }

    adatBe(vegpont, myCallBack) {
        fetch(vegpont, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': this.token,
            }
        })
            .then((response) => response.json())
            .then((data) => {
                
                this.#konyvekTomb = data;
                
                myCallBack(this.#konyvekTomb);
            })
            .catch((error) => {
                console.error('Error:', error);
            });
    }

    
}

export default KonyvModel;