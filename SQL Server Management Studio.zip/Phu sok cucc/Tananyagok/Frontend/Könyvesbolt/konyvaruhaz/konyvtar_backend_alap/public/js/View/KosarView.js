

class KosarView{
    #i;
    #ids = [];
    #price =0;
    constructor(parent, items){
        this.#i=1;
        $(parent).html(`<table><thead>`);
        for (const item of items) {
            
            $('table').append("<tr><td>"+item.cim+"</td><td>"+item.szerzo+"</td><td>"+item.ar+"</td><td id='"+this.#i+"' class='torol'>Törlés</td></tr>");
            this.#i++;  
            this.#price+=item.ar;
        }
        $('table').append("<tr><td></td><td>Összár:"+this.#price+"</td><td></td><td></td></tr>");
        $(parent).append(`</thead><tbody></tbody></table>`);
        $('.torol').on("click",()=>{
            this.kattintasTrigger("torol");

        });
        
    }


    kattintasTrigger(es){
        const esemeny = new CustomEvent(es,{detail:event.target.id});
        window.dispatchEvent(esemeny);
    }
}

export default KosarView;