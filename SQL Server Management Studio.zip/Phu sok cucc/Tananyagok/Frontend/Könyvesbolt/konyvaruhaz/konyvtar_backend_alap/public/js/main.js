import KonyvController from "/../js/Controller/KonyvController.js";
import KosarController from "/../js/Controller/KosarController.js";

$(function() {
    new KonyvController();
    new KosarController();
});