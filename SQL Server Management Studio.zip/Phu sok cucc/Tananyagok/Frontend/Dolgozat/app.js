import StoreController from "./Controller/StoreController.js";

$(function(){
    console.log("Invite Controller");
    new StoreController();
    console.log("Everything - OK UwU");
})