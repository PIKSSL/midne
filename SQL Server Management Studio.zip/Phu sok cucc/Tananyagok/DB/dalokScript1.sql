--use master; drop database dalok;
go
CREATE DATABASE dalok_
go
USE dalok_
go
-- T�BL�K ELK�SZ�T�SE
CREATE TABLE m�faj(
m_id int identity(100, 1),
elnevez�s char(50) not null,
primary key (m_id)
)

CREATE TABLE dal(
azon int identity(100, 1),
c�me char(50) not null,
keletkez�se date,
m�faja int not null,
eredetije int, 
PRIMARY KEY (azon)
)

CREATE TABLE platform(
platform char(30)
primary key(platform)
)

CREATE TABLE megjelent(
dal int,
d�tum date,
platform char(30) not null,
beszerz�s date
primary key (dal, d�tum)
)

CREATE TABLE SZEREP(
sz_id int identity(100, 1),
megnevez�s char(50) not null,
jogd�jas bit not null
primary key (sz_id)
)
 
CREATE TABLE SZEM_EGY(
k�d int identity(100, 1),
n�v char(50) not null,
kezd_�v smallint not null,
v�ge_�v smallint,
jelz�s char(1) not null,
primary key (k�d)
)

CREATE TABLE tagja(
egy�ttes int,
szem�ly int,
kezd_�v smallint not null,
v�ge_�v smallint,
primary key (egy�ttes, szem�ly, kezd_�v)
)




CREATE TABLE alkotja(
szem�ly int,
dal int,
szerep int,
primary key (szem�ly, dal, szerep)
)

CREATE TABLE v�lt(
szem�ly int,
dal int,
szerep int,
d�tumig date,
--primary key (szem�ly, dal, szerep)
)

CREATE TABLE el�adja(
szem_egy int,
dal int,
primary key (szem_egy, dal)
)
go
-- KK BE�LL�T�SA
ALTER table megjelent
add foreign key (dal) references dal (azon),
	foreign key (platform) references platform (platform)

alter table dal
add foreign key (m�faja) references m�faj (m_id),
	foreign key (eredetije) references dal (azon)

alter table alkotja
add foreign key (szem�ly) references szem_egy (k�d),
	foreign key (dal) references dal (azon),
	foreign key (szerep) references szerep (sz_id)

--alter table v�lt
--add foreign key (szem�ly) references szem_egy (k�d),
--	foreign key (dal) references dal (azon),
--	foreign key (szerep) references szerep (sz_id)

alter table tagja
add foreign key (egy�ttes) references szem_egy (k�d),
	foreign key (szem�ly) references szem_egy (k�d)

alter table el�adja
add foreign key (szem_egy) references szem_egy (k�d),
	foreign key (dal) references dal (azon)
go
-- Megszor�t�sok

-- Csak S v E-t lehessen be�rni a jelz�shez
CREATE FUNCTION SvE_E(@jelz�s char)
returns bit
begin
declare @v�lasz bit
if (@jelz�s='S' or @jelz�s='E')
	set @v�lasz = 1
else
	set @v�lasz = 0
return @v�lasz
end

go

alter table szem_egy
add check (dbo.SvE_E(jelz�s)=1)
go

create function nemKevesebb(@kezd smallint, @vege smallint)
returns bit
begin
declare @v�lasz bit

	if (@kezd<@vege)
		set @v�lasz = 1
	else
		set @v�lasz = 0
return @v�lasz
end
go

alter table szem_egy
add check (dbo.nemKevesebb(kezd_�v, v�ge_�v)=1 or v�ge_�v is null)

alter table tagja
add check (dbo.nemKevesebb(kezd_�v, v�ge_�v)=1 or v�ge_�v is null)

-- TESZT ADATOK
insert into m�faj
values('punk-rock'), ('pop-rock')

insert into dal
values ('Stacy''s Mom', '2003-05-19', 100, null),
('Stacy''s Mom', '2011-04-26', 100, 100)

insert into dal (c�me, keletkez�se, m�faja)
values('Motivation', '2002-01-05', 100),
('Fat Lip', '2001-04-11', 100),
('In Too Deep', '2001-09-25', 100),

('Summer Paradise', '2011-12-13', 101)

insert into platform
values ('CD'),
	('digit�lis')

insert into megjelent
values(100, '2003-10-13', 'CD', null),
	(101, '2011-10-10', 'digit�lis', null),
	
	(102, '2001-05-08', 'CD', null),
	(103, '2001-05-08', 'CD', null),
	(104, '2001-05-08', 'CD', null),

	(105, '2011-12-13', 'digit�lis', null)

insert into SZEM_EGY 
values('Fountains of Wayne', 1995, 2013, 'E'),
	('Adam Schlesinger', 1995, 2020, 'S'),
	('Chris Collingwood', 1995, null, 'S'),
	('Jody Porter', 1990, null, 'S'),
	('Brian Young', 1996, null, 'S'),

	('Bowling for Soup', 1994, null, 'E'),
	('Jaret Reddick', 1994, null, 'S'),
	('Chris Burney', 1994, null, 'S'),
	('Gary Wiseman', 1994, null, 'S'),
	('Rob Felicetti', 1994, null, 'S')

insert into SZEM_EGY(n�v, kezd_�v, jelz�s)
	values('Sum 41', 1996, 'E'),
	('Deryck Whibley', 1996, 'S'),
	('Dave Baksh',1996,'S'),
	('Jason McCaslin', 1996, 'S'),
	('Tom Thacker', 1993, 'S'),
	('Frank Zummo', 2001, 'S'),

	('Simple Plan', 1999, 'E'),
		('Pierre Bouvier', 1993, 'S'),
		('Chuck Comeau', 1993, 'S'),
		('Jeff Stinco ', 1999, 'S'),
		('S�bastien Lefebvre', 1999, 'S'),

		('Keinan Abdi Warsame', 2000, 'S'),

	('Blink 182', 1992, 'E'), --122
	('Tom DeLonge', 1992, 'S'), -- 2005
	('Scott Raynor', 1992, 'S'), --1998
	('Mark Allan Hoppus', 1992, 'S'), 
	('Travis Barker', 1993, 'S'),
	('Matt Skiba', 1992, 'S'),

	('Angels & Airwaves', 2005, 'E'),
	('Ilan Rubin', 1997, 'S'), --2011
	('Matt Rubano', 2000, 'S'), --2018
	('David Kennedy', 2000, 'S') --2018

insert into tagja
values(100, 101, 1995, 2013),
	(100, 102,  1995, 2013),
	(100, 103,  1995, 2013),
	(100, 104, 1996, 2013),

	(105, 106, 1994, null),
	(105, 107, 1994, null),
	(105, 108, 1994, null),
	(105, 109, 1994, null),

	(110, 111, 1996, null),
	(110, 112, 1998, null),
	(110, 113, 1999, null),
	(110, 114, 2006, null),
	(110, 115, 2015, null),

	(122, 123, 1992, 2005),
	(122, 124, 1992, 1998),
	(122, 125, 1992, null),
	(122, 126, 1993, null),
	(122, 127, 2015, null)

insert into tagja (egy�ttes, szem�ly, kezd_�v)
values(116, 116, 1999),
	(116, 117, 1999),
	(116, 118, 1999),
	(116, 119, 1999),
	(116, 120, 1999),

	(128, 123, 2005),
	(128, 129, 2011),
	(128, 130, 2018),
	(128, 131, 2018)



insert into SZEREP
values('zeneszerz�', 1),
	('sz�veg�r�',1) --hangszerel�

insert into alkotja
values(101, 100, 100),
	(101, 100, 101),
	(102, 100, 100),
	(102, 100, 101),

	(111, 102, 100),
	(111, 102, 101),
	(111, 103, 100),
	(111, 103, 101),
	(111, 104, 100),
	(111, 104, 101),

	(117, 105, 100),
	(117, 105, 101),
	(118, 105, 100),
	(118, 105, 101)


insert into el�adja
values(100, 100),
	(105, 101),
	(110, 102),
	(110, 103),
	(110, 104),
	(116, 105),
	(119, 105)

-- List�z�s
--select * from m�faj
--select * from dal
--select * from platform
--select * from megjelent
--select * from SZEM_EGY
--select * from tagja
--select * from SZEREP
--select * from alkotja
--select * from el�adja

--insert into SZEM_EGY
--values('tesztTag', 1999, null, 'S')

--insert into tagja
--values(105, 122, 2010, null)


-- nemEredeti tagok band�i
go
create view nemEredeti AS
select distinct egy�ttes from 
tagja t, 
(select k�d, kezd_�v from SZEM_EGY 
where jelz�s='E' and v�ge_�v is null) e
where t.egy�ttes=e.k�d and year(t.d�tumt�l)>e.kezd_�v
go

go
-- eredeti tagok band�i
create view eredeti As
select distinct egy�ttes from tagja t, 
(select k�d, d�tumt�l from SZEM_EGY 
where jelz�s='E' and v�ge_�v is null) e
where t.egy�ttes=e.k�d and year(t.v�ge_�v) is null and year(t.kezd_�v)=e.kezd_�v
go 



-- Melyik akt�v egy�ttesnek a tagjai csak eredeti tagok?
--select egy�ttes, n�v from eredeti inner join SZEM_EGY on k�d=egy�ttes
--where egy�ttes not in (select egy�ttes from nemEredeti)

--select egy�ttes, n�v from tagja inner join SZEM_EGY on egy�ttes=k�d where szem�ly=(
--select k�d from SZEM_EGY where n�v = 'Tom DeLonge')                

--alter table tagja
--add d�tumt�l date not null

--alter table tagja
--add d�tumig date

--alter table tagja
--alter column d�tumt�l date not null

--alter table tagja
--add primary key (egy�ttes, szem�ly, d�tumt�l)

--go

--update tagja set
--d�tumt�l = cast(cast(kezd_�v as char(4))+ '0101'as date),
--d�tumig = cast(cast(v�ge_�v as char(4))+ '1231'as date)

--select * from tagja

--alter table tagja
--drop column kezd_�v

--alter table tagja
--drop column v�ge_�v

--alter table tagja
--drop constraint [PK__tagja__293AD3D482B81DE9]
select * from szerep
select * from alkotja
select * from tagja
select * from SZEM_EGY
select * from dal
select * from el�adja
select * from SZEREP

select distinct seg1.dal 
from seg1 inner join alkotja a on seg1.dal = a.dal 
	where a.szerep = (select sz_id from szerep where megnevez�s = 'zeneszerzo') and seg1.szem�ly = a.szem�ly





--insert into dal
--values('teszt','2000-01-01',100,106)

--insert into alkotja
--values(131,106,100)

--insert into el�adja
--values(131,106)

--Mely daloknak a feldolgoz�sai m�s m�faj�?
select d2.azon as 'eredeti',d2.m�faja, d1.azon 'feldolgozas',d1.m�faja
from dal d1, dal d2
where d1.eredetije = d2.azon and d1.m�faja <> d2.m�faja


--Ki mit alkotott utolj�ra?

select a.szem�ly, d.azon
from alkotja a inner join dal d on a.dal = d.azon
where d.keletkez�se = (select MAX(keletkez�se) from dal where azon = d.azon) 


go
create trigger napl�z
on alkotja
after update
as
begin
	declare @szem int, @dal int, @szer int
	select @szem=szem�ly, @dal=dal, @szer=szerep from deleted
	insert into v�lt values (@szem, @dal, @szer, getdate())
end
go

update alkotja set
szem�ly =118
where szem�ly = 101 and dal = 100 and szerep = 100

select * from v�lt 
select * from alkotja