CREATE DATABASE DALOK

use DALOK

--t�bl�k elk�sz�t�se

CREATE TABLE DAL
(
AZON int identity(1000,1),
CIME char(40) not null,
KELETKEZES date not null,
MUFAJ int not null,
EREDETIJE int,
PRIMARY KEY (AZON)
)

CREATE TABLE MUFAJ
(
M_ID int identity(100,1),
ELNEVEZES char(30) not null,
PRIMARY KEY (M_ID)
)

CREATE TABLE SZAM_EGY
(
KOD int identity(100,1),
NEV char(40) not null,
KEZD_EV date not null,
VEGE_EV date,
JELZES char(1) not null,
PRIMARY KEY (KOD)
)

CREATE TABLE TAGJA
(
EGYUTTES int,
SZEMELY int,
DATUMTOL date,
DATUMIG date,
PRIMARY KEY (EGYUTTES, SZEMELY, DATUMTOL)
)

CREATE TABLE PLATFORM_
(
PLATFORM_ char(30),
PRIMARY KEY (PLATFORM_)
)

CREATE TABLE ALKOTJA 
(
SZEMELY int,
DAL int,
SZEREP int,
PRIMARY KEY (SZEMELY, DAL, SZEREP)
)

CREATE TABLE SZEREP 
(
SZEMELY_ID int identity (100,1),
MEGNEVEZES char(30) not null,
JOGDIJAS bit not null,
PRIMARY KEY (SZEMELY_ID)
)
CREATE TABLE MEGJELENT
(
DAL int,
DATUM date,
PLATFORM_ char (30) not null,
BESZERZES bit not null,
PRIMARY KEY (DAL,DATUM)
)

CREATE TABLE VALT
(
SZEMELY int,
DAL int,
SZEREP int,
DATUMIG date not null,
PRIMARY KEY (SZEMELY, DAL, SZEREP)
)
CREATE TABLE ELOADJA 
(
SZEM_EGY int,
DAL int
PRIMARY KEY (SZEM_EGY, DAL)
)

--�sszek�t�s
ALTER TABLE MEGJELENT
ADD FOREIGN KEY (DAL) REFERENCES DAL (AZON), FOREIGN KEY (PLATFORM_) REFERENCES PLATFORM_ (PLATFORM_)

ALTER TABLE DAL
ADD FOREIGN KEY (MUFAJ) REFERENCES MUFAJ (M_ID), FOREIGN KEY (EREDETIJE) REFERENCES DAL (AZON)

ALTER TABLE ALKOTJA
ADD FOREIGN KEY (SZEMELY) REFERENCES SZAM_EGY (KOD), FOREIGN KEY (DAL) REFERENCES DAL (AZON), FOREIGN KEY (SZEREP) REFERENCES SZEREP (SZEMELY_ID)

ALTER TABLE VALT
ADD FOREIGN KEY (SZEMELY) REFERENCES SZAM_EGY (KOD), FOREIGN KEY (DAL) REFERENCES DAL (AZON), FOREIGN KEY (SZEREP) REFERENCES SZEREP (SZEMELY_ID)

ALTER TABLE TAGJA
ADD FOREIGN KEY (EGYUTTES) REFERENCES SZAM_EGY (KOD), FOREIGN KEY (SZEMELY) REFERENCES SZAM_EGY (KOD)

ALTER TABLE ELOADJA
ADD FOREIGN KEY (SZEM_EGY) REFERENCES SZAM_EGY (KOD), FOREIGN KEY (DAL) REFERENCES DAL (AZON)

-- MUFAJ, DAL, PLATFORM_, MEGJELENT, SZAM_EGY, TAGJA, SZEREP, ALKOTJA, ELOADJA 
INSERT INTO MUFAJ
VALUES 
('Pop'),
('Rock'),
('Rap'),
('Dubstep'),
('Metal'),
('Jazz')

INSERT INTO PLATFORM_
VALUES
('YouTube'),
('Spotify'),
('Apple Music'),
('Bakelit lemez'),
('CD'),
('SoundCloud')


INSERT into DAL
--values ('nemjo', '2000-01-01',101,1001)
values ('nemjo2','2000-10-10',101,1033)

select * from dal

INSERT INTO DAL
VALUES 
('Shivers','2021-10-10',101,NULL),
('Bad Habits','2021-10-10',101,NULL),
('Tides','2021-10-10',101,NULL),
('First times','2021-10-10',101,NULL),
('Overpass graffiti','2021-10-10',101,NULL),
('The Joker And The Queen','2021-10-10',101,NULL),
('Shivers','2021-10-10',101,NULL),
('Enemy','2021-10-28',101,NULL),
('My Life','2021-9-4',101,NULL),
('Lonely','2021-9-4',101,NULL),
('Wrecked','2021-7-15',101,NULL),
('Monday','2021-9-24',101,NULL),
('Enemy','2021-10-28',101,NULL),
('#1','2021-9-7',101,NULL),
('Easy Come Easy Go','2021-9-3',101,NULL),
('Giants','2021-9-7',101,NULL),
('Its Ok','2021-9-4',101,NULL),
('Dull Knives','2021-9-4',101,NULL),
('Follow You','2021-3-16',101,NULL),
('Cutthroat','2021-5-5',101,NULL),
('No Time For Toxic People','2021-9-4',101,NULL),
('One Day ','2021-9-4',101,NULL),
('Bones','2021-4-6',101,NULL),
('Symphony ','2022-7-1',101,NULL),
('Sharks ','2022-6-24',101,NULL),
('I Dont Like Myself','2022-7-1',101,NULL),
('Blur ','2022-7-1',101,NULL),
('Higher Ground','2022-7-1',101,NULL),
('Shivers remix','2022-01-25',101,1027),
('Bohemian Rhapsody','2008-8-1',101,NULL),
('Dont Stop Me Now','2008-8-1',101,NULL),
('The Show Must Go On','2013-10-15',101,NULL)

INSERT INTO MEGJELENT
VALUES
('1029','2008-08-1','CD',0),
('1030','2008-08-1','CD',0),
('1031','2013-10-15','CD',0),
('1027','2022-01-25','Spotify',0),
('1021','2021-10-10','SoundCloud',0),
('1022','2021-10-10','SoundCloud',0),
('1023','2021-10-10','SoundCloud',0),
('1024','2021-10-10','SoundCloud',0),
('1025','2021-10-10','SoundCloud',0),
('1026','2021-10-10','SoundCloud',0),
('1027','2021-10-10','SoundCloud',0),
('1000','2021-10-28','Spotify',1),
('1001','2021-9-4','Spotify',1),
('1002','2021-9-4','Spotify',1),
('1003','2021-7-15','Spotify',1),
('1004','2021-9-24','Spotify',1),
('1005','2021-10-28','Spotify',1),
('1006','2021-9-7','Spotify',1),
('1007','2021-9-3','Spotify',1),
('1008','2021-9-7','Spotify',1),
('1009','2021-9-4','Spotify',1),
('1010','2021-9-4','Spotify',1),
('1011','2021-3-16','Spotify',1),
('1012','2021-5-5','Spotify',1),
('1013','2021-9-4','Spotify',1),
('1014','2021-9-4','Spotify',1),
('1015','2021-4-6','Spotify',1),
('1016','2022-7-1','Spotify',1),
('1017','2022-6-24','Spotify',1),
('1018','2022-7-1','Spotify',1),
('1019','2022-7-1','Spotify',1),
('1020','2022-7-1','Spotify',1)


INSERT INTO SZAM_EGY
VALUES 
('Queen',1970,NULL,'E'),
('Freddie Mercury',1970,1991,'S'),
('Brian Harold May',1970,NULL,'S'),
('John Richard Deacon',1971,1997,'S'),
('Roger Meddows Taylor',1971,NULL,'S'),
('Edward Christopher Sheeran',2011,NULL,'S'),
('Imagine Dragons',2008,NULL,'E'),
('Dan Reynolds',2008,NULL,'S'),
('Wayne Sermon',2008,NULL,'S'),
('Ben McKee',2008,NULL,'S'),
('Andrew Tolman',2008,2012,'S'),
('Theresa Flaminio',2008,2012,'S'),
('Dave Lemke',2008,2012,'S'),
('Andrew Beck',2008,2012,'S'),
('Aurora Florence',2008,2012,'S'),
('FEDUK & SLAVA MARLOW',2019,NULL,'E'),
('FEDUK',2018,NULL,'S'),
('SLAVA MARLOW',2017,NULL,'S')

SELECT * FROM SZAM_EGY
INSERT INTO TAGJA
VALUES 
(110, 111, '2019-04-05',NULL),
(110, 112, '2019-04-05',NULL),
(100, 103, '2008-01-01',NULL),
(100, 104, '2008-01-01',NULL),
(100, 101, '2008-01-01',NULL),
(100, 102, '2008-01-01',NULL),
(100, 106, '2008-01-01','2012-01-01'),
(100, 107, '2008-01-01','2012-01-01'),
(100, 108, '2008-01-01','2012-01-01'),
(100, 105, '2008-01-01','2012-01-01'),
(113, 114, '1970-2-4','1991-7-14'),
(113, 115, '1970-5-7',NULL),
(113, 116, '1971-3-13','1997-7-14'),
(113, 117, '1971-3-6',NULL)


INSERT INTO SZEREP
VALUES
('Zeneszerz�',1),
('Sz�veg�r�',1),
('Git�r sz�l�',0),
('Hangszerel�',0)


INSERT INTO ALKOTJA
VALUES 
(114,1029,100),
(115,1029,103),
(116,1029,102),
(117,1029,101),
(114,1030,100),
(115,1030,103),
(116,1030,102),
(117,1030,101),
(114,1031,100),
(115,1031,101),
(115,1031,103),
(115,1031,102),
(111,1028,100),
(112,1028,100),
(101,1000,101),
(102,1000,102),
(103,1000,103),
(101,1001,101),
(103,1001,102),
(104,1001,103),
(101,1002,101),
(102,1002,102),
(104,1002,103),
(101,1003,101),
(102,1003,102),
(103,1003,103),
(101,1004,101),
(102,1004,103),
(103,1004,102),
(101,1005,101),
(103,1005,103),
(103,1005,102),
(101,1006,101),
(102,1006,103),
(103,1006,102),
(101,1007,101),
(104,1007,103),
(102,1007,100),
(101,1008,100),
(102,1008,103),
(103,1008,102),
(101,1009,101),
(102,1009,103),
(103,1009,102),
(101,1010,101),
(102,1010,103),
(103,1010,102),
(101,1011,101),
(102,1011,103),
(103,1011,102),
(101,1012,101),
(102,1012,103),
(103,1012,102),
(101,1013,101),
(104,1013,102),
(102,1013,103),
(101,1014,100),
(102,1014,101),
(103,1014,102),
(101,1015,101),
(102,1015,100),
(103,1015,102),
(101,1016,101),
(102,1016,103),
(103,1016,102),
(101,1017,101),
(102,1017,103),
(103,1017,102),
(101,1018,100),
(103,1018,102),
(104,1018,102),
(101,1019,101),
(102,1019,102),
(104,1019,103),
(101,1020,101),
(102,1020,103),
(103,1020,102),
(109,1021,101),
(109,1022,101),
(109,1023,101),
(109,1024,101),
(109,1025,101),
(109,1026,101),
(109,1027,101)



INSERT INTO ELOADJA
VALUES 
(113,1029),
(113,1030),
(113,1031),
(100,1000),
(100,1001),
(100,1002),
(100,1003),
(100,1004),
(100,1005),
(100,1006),
(100,1007),
(100,1008),
(100,1009),
(100,1010),
(100,1011),
(100,1012),
(100,1013),
(100,1014),
(100,1015),
(100,1016),
(100,1017),
(100,1018),
(100,1019),
(100,1020),
(109,1021),
(109,1022),
(109,1023),
(109,1024),
(109,1025),
(109,1026),
(109,1027)

--List�z�s
SELECT * FROM MUFAJ
SELECT * FROM DAL
SELECT * FROM PLATFORM_
SELECT * FROM MEGJELENT
SELECT * FROM SZAM_EGY
SELECT * FROM TAGJA
SELECT * FROM SZEREP
SELECT * FROM ALKOTJA
SELECT * FROM ELOADJA

SELECT * FROM VALT
--F�ggv�nyek

go
CREATE FUNCTION JELZES_SZEM_EGYUTTES(@jelz�s char)
returns bit
begin
declare @v�lasz bit
if (@jelz�s='S' or @jelz�s='E')
    set @v�lasz = 1
else
    set @v�lasz = 0
return @v�lasz
end

go

ALTER TABLE SZAM_EGY
ADD CHECK (dbo.JELZES_SZEM_EGYUTTES(JELZES) = 1)
go

--DAL, AMELYNEK AZ EREDETIJE EGY FELDOLGOZ�S
--allek�rdez�s
create view nemEredetire
as
select * from DAL
where EREDETIJE is not null and EREDETIJE in (select azon from DAL where EREDETIJE is not null)

select * from nemEredetire

delete from DAL
where azon = 1033

select * from dal

insert into dal
values ('nemjo3','2000-10-10',101,1033)

--innerjoin
create view nemEredetireB
as
select * from DAL d inner join DAL de on d.EREDETIJE = de.AZON 
where de.EREDETIJE is not null

--ahol a jelz�s nem S �s nem E
create view ellen2
as
select * from SZAM_EGY
where JELZES <> 'E' AND JELZES <> 'S'

update SZAM_EGY set
JELZES = 'A'
where KOD =100
--V�ge �v nagyobb mint a kezd�si �v vagy �res
select * from SZAM_EGY

--Tagja egy�ttes jelz�se nem egy�ttes vagy a szem�ly nem szem�ly
select * from TAGJA t
where t.EGYUTTES in (select kod from SZAM_EGY where JELZES <> 'E') 
or t.SZEMELY in (select kod from SZAM_EGY where JELZES <> 'S')

create view ellen3
as
select * from TAGJA t inner join SZAM_EGY e on t.EGYUTTES = e.KOD inner join SZAM_EGY sz on t.SZEMELY = sz.KOD
where e.JELZES <> 'E' or sz.JELZES <> 'S'

select * from SZAM_EGY

--Az alkot�k csak szem�lyek lehetnek
create view ellen4
as
select * from ALKOTJA a inner join SZAM_EGY sz on a.SZEMELY = sz.KOD
where JELZES <> 'S'

select * from SZAM_EGY
select * from ALKOTJA
--Csak eredeti dal alkot�i szerepe lehet jogd�jas
create view ellen5 as
select * from ALKOTJA a inner join SZEREP sz on a.SZEREP = sz.SZEMELY_ID inner join DAL d on d.AZON = d.EREDETIJE
where  JOGDIJAS = 1 or EREDETIJE is not null--a.DAL not in (select azon from nemEredetire)

--Egy dal el�ad� csupa k�l�nb�z� szem�lyek 
create view seg�d1
as
select dal, SZEMELY, 'zkri tag' as megj from ELOADJA e inner join TAGJA t on e.SZEM_EGY = t.EGYUTTES inner join DAL d on e.DAL = d.AZON
where CAST(year(d.KELETKEZES) as smallint) between  CAST(year(t.DATUMTOL) as smallint) and isnull( CAST(year(t.DATUMIG) as smallint), CAST(year(getdate()) as smallint))
UNION all
select dal, szem_egy, 'vend�g ea' from ELOADJA e inner join SZAM_EGY sz on e.SZEM_EGY = sz.KOD
where JELZES = 'S'

select dal, count(*) as mindenki, count(distinct SZEMELY) as k�l_szem
from seg�d1
group by dal
having count(*)<>COUNT(distinct SZEMELY)

select * from dal

select * from TAGJA