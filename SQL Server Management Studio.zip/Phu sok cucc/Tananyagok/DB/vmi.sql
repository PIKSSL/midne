--ellenörző lekérdezések

-- olyan rossz rekordok ahol a feldolgozás nem egy eredetire mutat
go
create view ellen1b AS
select * from dal where eredetije not in (select azon from dal where eredetije is null)
go

go
create view ellen1 AS
select d2.* from dal d1, dal d2
where d1.azon = d2.eredetije
and d1.eredetije is not null
go

select * from ellen1

insert into dal
values('hibasdal', '2022-02-02', 100, 101)

delete from dal
where azon=107

alter table tagja
drop constraint [CK__tagja__4316F928]

-- csak E vagy S e?
go
create view ellen2 AS
select * from SZEM_EGY
where jelzés <> 'S' AND jelzés <> 'E'
go

update szem_egy set
jelzés='E'
where kód=100

alter table szem_egy
drop constraint [CK__SZEM_EGY__jelzés__403A8C7D]

-- tagja t-ben az egy nem egy vagy a szen ben személy
go
create view ellen4 AS
select együttes, személy, e1.név as egy_név, e1.jelzés as egy_jel, s2.név as s_név, s2.jelzés as s_jel from tagja 
	inner join SZEM_EGY e1 on együttes = e1.kód 
	inner join SZEM_EGY s2 on személy = s2.kód
	where e1.jelzés <> 'E' OR s2.jelzés <> 'S'
go
update SZEM_EGY set
jelzés = 'E'
where kód = 100

select * from ellen4

delete from tagja
--select * from tagja
where együttes=116 and személy=116

go
create view ellen4b AS
select * from tagja
where együttes not in (select kód from SZEM_EGY where jelzés = 'E')
or
személy not in (select kód from SZEM_EGY where jelzés = 'S')
go
select * from ellen4b

go
--személy az alkotó
create view ellen5 AS
select * from alkotja, SZEM_EGY
where személy=kód and jelzés <> 'S'
go

select * from ellen5

insert into alkotja
values(100, 101, 100)

delete from alkotja
where személy=100 and dal=101

select * from alkotja, dal
where eredetije is not null and dal=azon

go
create view ellen7 AS
select * from alkotja a
	inner join SZEREP on szerep=sz_id
	inner join dal d on a.dal = d.azon
where jogdíjas = 1 /*NOT előtag*/ and /*utótag*/ eredetije is not null -- ha akkor not f1 or f2
go

insert into alkotja
values(101, 101, 100)

delete from alkotja
where személy=101 and dal=101

select * from ellen7

select * from előadja
	inner join SZEM_EGY on szem_egy = kód
where jelzés='E'

select * from tagja
	inner join szem_egy on személy=kód
where együttes=116

select * from dal
go
alter view seg1 AS
select dal, személy from előadja e
	inner join tagja tg on e.szem_egy = tg.együttes
	inner join dal d on d.azon = e.dal
where keletkezése between dátumtól and isnull(dátumig, getdate())

union
select dal, szem_egy
from előadja
	inner join szem_egy on kód=szem_egy
	where jelzés = 'S'
go

update előadja set
szem_egy = 121
where szem_egy = 119 and dal = 105

select * from előadja
select * from SZEM_EGY

go
create view ellen9 as
select dal, count(*) as mindenki, COUNT(distinct személy) as kül_szem from seg1
group by dal
having count(*) <> COUNT(distinct személy)
go