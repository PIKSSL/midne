package kinezet;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.WindowConstants;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class Jatek_gui_V03 implements ActionListener{

    private JFrame frame;
    JMenuItem jitem;
    JMenu jm1;
    JMenu jm2;
    public static void main(String[] args) {
        new Jatek_gui_V03();
    }
    
    public Jatek_gui_V03(){
        ini();
    }
    
    private void ini(){
        frame = new JFrame("V03 Itt a piros...");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(450, 300);
        
        JMenuBar jbar = new JMenuBar();
        jm1 = new JMenu("Program");
        jm2 = new JMenu("Egyéb");
        jbar.add(jm1);
        jbar.add(jm2);
        
         jitem = new JMenuItem("1. opc", new ImageIcon(this.getClass().getResource("/kepek/uwu.PNG")));
        jm1.add(jitem);
        
        jm1.setMnemonic(KeyEvent.VK_P);
        jm2.setMnemonic(KeyEvent.VK_S);
        
        jitem.addActionListener(this);
        
        
        JPanel jpm = new JPanel();
        jpm.add(jbar);
        jbar.setBackground(Color.LIGHT_GRAY);
        
        LayoutManager lymFlowFelso = new FlowLayout(FlowLayout.CENTER);
        JPanel pnlFelso = new JPanel(lymFlowFelso);
        pnlFelso.setBorder(new TitledBorder("Leírás"));
        
        
        JPanel klikkPanel = new JPanel();
        klikkPanel.setBorder(new LineBorder(Color.BLACK));
        JLabel klikksz = new JLabel("<html><p>Játék:1 Klikk:0</p><p>Összes klikk:0</p></html>");
        klikkPanel.add(klikksz);
        
        JLabel lblLeiras = new JLabel("<html><p>Itt a piros, hol a piros?</p><center>Mi a tipp?</center></html>");
        
        pnlFelso.add(lblLeiras);
        pnlFelso.add(klikkPanel);
        
        LayoutManager lymGridAlso = new GridLayout(2,1);
        JPanel pnlAlso = new JPanel(lymGridAlso);//grid: pnlAlsoJatektter és pnlAlsoLeiras
        pnlAlso.setBorder(new TitledBorder("Játéktér"));
                
        LayoutManager lymFlowAlso = new FlowLayout(FlowLayout.LEFT);
        JPanel pnlAlsoJatekter = new JPanel(lymFlowAlso);//pnlAlso-n lesz, gombokat tartalmaz
        JPanel pnlAlsoLeiras = new JPanel(lymFlowAlso);//pnlAlso-n lesz, labelt tartalmaz
        
        pnlAlso.add(pnlAlsoJatekter);//pnlAlso grid 1. sora
        pnlAlso.add(pnlAlsoLeiras);//pnlAlso grid 2. sora

        JButton gomb1 = new JButton("1");
        JButton gomb2 = new JButton("2");
        JButton gomb3 = new JButton("3");
        pnlAlsoJatekter.add(gomb1);
        pnlAlsoJatekter.add(gomb2);
        pnlAlsoJatekter.add(gomb3);
        
        JLabel lblVissza = new JLabel("<html><p>Találat visszajelzés!</p></html>");
        pnlAlsoLeiras.add(lblVissza);
        
        LayoutManager lymGridFrame = new GridLayout(2, 1);
        double x = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        double y = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        int xx = (int)x/2-150;
        int yy = (int)y/2-125;
        
        System.out.println(x);
        frame.setJMenuBar(jbar);
        frame.setLayout(lymGridFrame);
        frame.getContentPane().add(pnlFelso);
        frame.getContentPane().add(pnlAlso);
        frame.setBounds(xx,yy,300,250);
//        frame.setLocation(xx,yy);
//        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        jitem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,ActionEvent.CTRL_MASK));
        jm1.addSeparator();
        jm1.add(new JMenuItem("kilépés"));
        
    }
}
