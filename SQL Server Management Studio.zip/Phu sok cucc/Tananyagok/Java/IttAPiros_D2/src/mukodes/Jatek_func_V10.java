package mukodes;

import com.sun.java.swing.plaf.windows.resources.windows;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.ResourceBundle;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.WindowConstants;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class Jatek_func_V10 implements ActionListener {

    JLabel lblStatisztika;
    private int kattintasMinden;
    private int kattintasJatek;
    private int ujjatek;
    private JPanel pnlAlsoJatekter;
    private JFrame frame;
    private JLabel lblVissza;
    private JMenuBar menuBar;
    private JPanel pnlFelso;
    private JPanel pnlAlso;

    public static void main(String[] args) {
        new Jatek_func_V10();
    }

    public Jatek_func_V10() {
        this.kattintasMinden = 0;
        this.ujjatek = 0;
        this.kattintasJatek = 0;
        ini();
    }

    private void ini() {
        /* A FŐ ablak beállításai */
        frame = new JFrame("V1.0 Itt a piros...");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        //frame.setSize(300, 250);//középre rakjuk

        /* középre */
        Dimension kep = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setBounds(kep.width / 2 - 150, kep.height / 2 - 125, 300, 250);

        /* MENÜ */
        menuBar = new JMenuBar();
        JMenu mnuPrg = new JMenu("Program");
        mnuPrg.setMnemonic(KeyEvent.VK_P);
        JMenu mnuEgyeb = new JMenu("Egyéb");
        mnuEgyeb.setMnemonic(KeyEvent.VK_E);
        menuBar.add(mnuPrg);
        menuBar.add(mnuEgyeb);

        //JMenuItem mnuPrgUjra = new JMenuItem("Újra");
        JMenuItem mnuPrgUjra = new JMenuItem("Újra", new ImageIcon(this.getClass().getResource("/kepek/folder.gif")));
        mnuPrgUjra.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.CTRL_MASK));
        mnuPrgUjra.addActionListener(new Belso());
        mnuPrg.add(mnuPrgUjra);

        mnuPrg.addSeparator();

        JMenuItem mnuPrgKilep = new JMenuItem("Kilép...");
        mnuPrgKilep.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, ActionEvent.ALT_MASK));
        mnuPrgKilep.addActionListener(new Belso2());
        mnuPrg.add(mnuPrgKilep);

        // ez nem jó a menühöz:
        //frame.getContentPane().add(pnlMenu);
        //JPanel pnlMenu = new JPanel(new FlowLayout(FlowLayout.LEFT));
        //pnlMenu.add(menuBar);
        frame.setJMenuBar(menuBar);

        /* TARTALOM */
        LayoutManager lymGridFrame = new GridLayout(2, 1);//pnlAlso, pnlFelso
        frame.setLayout(lymGridFrame);
        /* felső */
        LayoutManager lymFlowFelso = new FlowLayout(FlowLayout.CENTER);
        pnlFelso = new JPanel(lymFlowFelso);
        pnlFelso.setBorder(new TitledBorder("Leírás"));

        /* also */
        LayoutManager lymGridAlso = new GridLayout(2, 1);
        pnlAlso = new JPanel(lymGridAlso);//grid: pnlJatektter és pnlAlsoLeiras
        pnlAlso.setBorder(new TitledBorder("Játéktér"));

        frame.getContentPane().add(pnlFelso);
        frame.getContentPane().add(pnlAlso);
        ujjatek();

        frame.setVisible(true);
    }

    private void ujjatek() {
        ujjatek++;
        pnlFelso.removeAll();
        pnlAlso.removeAll();

        /* felső tartalma */
        JPanel pnlFelsoLeiras = new JPanel();
        JLabel lblLeiras = new JLabel("<html><p>Itt a piros, hol a piros?</p><center>Mi a tipp?</center></html>");
        pnlFelsoLeiras.add(lblLeiras);

        JPanel pnlFelsoStatisztika = new JPanel();
        pnlFelsoStatisztika.setBorder(new LineBorder(Color.BLACK));
        lblStatisztika = new JLabel("<html><p>Játék:" + ujjatek + ", klikk: " + kattintasJatek + "</p><p>Összes klikk: " + kattintasMinden + "</p></html>");
        pnlFelsoStatisztika.add(lblStatisztika);

        pnlFelso.add(pnlFelsoLeiras);
        pnlFelso.add(pnlFelsoStatisztika);

        /* alsó tartalma */
        LayoutManager lymFlowAlso = new FlowLayout(FlowLayout.LEFT);
        pnlAlsoJatekter = new JPanel(lymFlowAlso);//pnlAlso-n lesz, gombokat tartalmaz
        JPanel pnlAlsoLeiras = new JPanel(lymFlowAlso);//pnlAlso-n lesz, labelt tartalmaz

        //JLabel lblVissza = new JLabel("<html><p>Találat visszajelzés!</p></html>");
        lblVissza = new JLabel("<html><p>Találat visszajelzés!</p></html>");
        pnlAlsoLeiras.add(lblVissza);

        JButton gomb1 = new JButton("1");
        JButton gomb2 = new JButton("2");
        JButton gomb3 = new JButton("3");

        gomb1.addActionListener(new Belso3());
        gomb2.addActionListener(new Belso3());
        gomb3.addActionListener(new Belso3());

        pnlAlsoJatekter.add(gomb1);
        pnlAlsoJatekter.add(gomb2);
        pnlAlsoJatekter.add(gomb3);

        setStatus(true);

        pnlAlso.add(pnlAlsoJatekter);//pnlAlso grid 1. sora
        pnlAlso.add(pnlAlsoLeiras);//pnlAlso grid 2. sora
        frame.pack();
    }

    private boolean randomGoiszli(JButton jb) {
        int O = (int) (Math.random() * 3) + 1;
        if (O == Integer.parseInt(jb.getText())) {
            return true;
        }
        return false;
    }

    private JButton[] getButtons() {
        JButton[] jbuts = new JButton[3];
        int c = 0;
        for (int i = 0; i < pnlAlsoJatekter.getComponentCount(); i++) {
            if (pnlAlsoJatekter.getComponent(i) instanceof JButton) {
                jbuts[c] = (JButton) pnlAlsoJatekter.getComponent(i);
                c++;
            }

        }
        return jbuts;
    }

    private void setStatus(boolean b) {
        for (JButton object : getButtons()) {
            object.setEnabled(b);
        }

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        frame.setDefaultCloseOperation(JOptionPane.showConfirmDialog(null, "Biztos kilépsz?", "KILÉPÉS", JOptionPane.YES_NO_OPTION));
    }

    public void setStat() {
        lblStatisztika.setText("<html><p>Játék:" + ujjatek + ", klikk: " + kattintasJatek + "</p><p>Összes klikk: " + kattintasMinden + "</p></html>");
    }

    class Belso implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            ujjatek();
        }
    }

    private void kilepes() {
        int v = JOptionPane.showConfirmDialog(null, "Biztos kilépsz?", "KILÉPÉS", JOptionPane.YES_NO_OPTION);
        if (v == 0) {
            System.exit(0);
        }
    }

    class Belso2 implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            kilepes();
        }

    }

    class Belso3 implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            //JOptionPane.showConfirmDialog(frame, "Kilépés", "Biztos kilép?", JOptionPane.YES_NO_OPTION);
            JButton gomb = (JButton) e.getSource();
            String felirat = gomb.getActionCommand();
            System.out.println("kattintott gomb szövege: " + felirat);
            kattintasJatek++;
            if (randomGoiszli(gomb)) {
                gomb.setText("O");
                lblVissza.setText("Talált!");
            } else {
                gomb.setText("X");
                lblVissza.setText("Nem talált!");
            }
            setStatus(false);

        }
//        lblStatisztika.updateUI();

    }

}
