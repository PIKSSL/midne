package tipuskenyszeritesek;

class Allat{ public void alszik(){}; }
class Kutya extends Allat{  public void ugat(){}; }
class Macsek extends Allat{  public void nyavog(){}; }

public class Tipuskenyszeritesek {

    public static void main(String[] args) {
        /* lehet */
        Allat a1 = new Allat();
        Allat a2 = new Kutya();
        a1.alszik();
        a2.alszik();
        Kutya k1 = (Kutya)a2;
        k1.alszik();
        k1.ugat();
        ((Kutya)a2).ugat();
        
        /* nem lehet */
        //Kutya k2 = new Allat();
        //Kutya k3 = (Kutya)new Allat();//ClassCastException
        ((Kutya)a1).ugat();//ClassCastException
    }
    
}
